package pelops.dao;

public class AdresTipiDAO {

}
