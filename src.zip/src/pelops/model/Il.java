package pelops.model;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="TNM_IL")
public class Il extends BaseEntity{

	@Column(name="ADI")
	private String adi;
	
	@Column(name="KODU")
	private int kodu;
	
	@OneToMany(fetch=FetchType.LAZY,mappedBy="il")
	private List<Ilce> ilceListesi;

}
