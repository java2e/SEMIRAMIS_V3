package pelops.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="TNM_TELEFON_TURU")
public class TelefonTuru extends BaseEntity{

	@Column(name="ADI")
	private String adi;

}
