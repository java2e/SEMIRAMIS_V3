package pelops.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="TNM_ADRES_STATUSU")
public class AdresStatusu extends BaseEntity {

	@Column(name="STATU")
	private String statu;
	
}
