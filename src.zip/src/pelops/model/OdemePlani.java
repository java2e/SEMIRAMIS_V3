package pelops.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="TNM_ODEME_PLANI")
public class OdemePlani extends BaseEntity{
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="ICRA_DOSYASI_ID")
	private IcraDosyasi icraDosyasi;
	
	@Column(name="KALAN_ALACAK_MIKTARI")
	private double kalanAlacakMiktari;
	
	@Column(name="PESINAT_MIKTARI")
	private double pesinatMiktari;
	
	@Column(name="TAKSIT_AYLIK_MIKTAR")
	private double taksitAylikMiktar;
	
	@Column(name="ODENECEK_MIKTAR")
	private double odenecekMiktar;
	
	@Column(name="TAKSIT_ADEDI")
	private int taksitAdedi;
	
	@Column(name="ILK_ODEME_TARIHI")
	private Date IlkOdemeTarihi;
	
	@Column(name="TAKSIT_TARIHLERI")
	private Date taksitTarihleri;
	
	@Column(name="DURUM")
	private String durum;
	
	@Column(name="TAKSIT_AYLAR")
	private String taksitAylar;
	
	
}
