package pelops.model;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="TNM_ALACAKLI_BILGISI")
public class AlacakliBilgisi extends BaseEntity {
	
	@OneToMany(fetch=FetchType.LAZY,mappedBy="alacakliBilgisi")
	private List<IcraDosyasi> icraDosya;
	
	@Column(name="SUBE_TIPI_ID")
	private int subeTipiId;

	@Column(name="MUVEKKIL_TIPI_ID")
	private int muvekkilTipiId;

	@Column(name="MUVEKKIL_ADI")
	private String muvekkilAdi;

	@Column(name="MUVEKKIL_SUBE_ADI")
	private String muvekkilSubeAdi;

	@Column(name="TICARET_SICIL_NO")
	private String ticaretSicilNo;

	@Column(name="MUSTERI_NO")
	private String musteriNo;

	@Column(name="VERGI_NO")
	private String vergiNo;

	@Column(name="VERGI_DAIRESI")
	private String vergiDairesi;

	@Column(name="EPOSTA")
	private String ePosta;

	@Column(name="WEB_ADRES")
	private String webAdres;

	@Column(name="NOTLAR")
	private String notlar;
	
	@OneToMany(fetch=FetchType.LAZY,mappedBy="alacakliBilgisi")
	private List<Adres> adres;

}
