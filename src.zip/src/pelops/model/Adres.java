package pelops.model;

import javax.persistence.*;

import org.hibernate.annotations.ForeignKey;

import semiramis.operasyon.model.BorcluBilgisi;

@Entity
@Table(name="TNM_ADRES")
public class Adres extends BaseEntity{

	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="IL_ID")
	private Il il ;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="ILCE_ID")
	private Ilce ilce;
	
	@Column(name="ADRES")
	private String adres;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="ADRES_STATUSU_ID")
	private AdresStatusu adresStatusu;
	
	@Column(name="SEMT_ADI")
	private String semtAdi;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="BORCLU_ID")
	private BorcluBilgisi borcluId ;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="ALACAKLI_BILGISI_ID")
	private AlacakliBilgisi alacakliBilgisi;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="AVUKAT_ID")
	private Avukat avukat;
	
	
}
