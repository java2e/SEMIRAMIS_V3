package pelops.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import semiramis.operasyon.model.BorcluBilgisi;

@Entity
@Table(name="TNM_HACZE_ESAS_MAL_BILGISI")
public class HaczeEsasMalBilgisi extends BaseEntity{

	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="BORCLU_BILGISI_ID")
	private BorcluBilgisi borcluBilgisi;
	
	@Column(name="MENKUL_BILGISI")
	private String menkulBilgisi;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="IL_ID")
	private Il il;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="ILCE_ID")
	private Ilce ilce;
	
	@Column(name="TAPU_MAHALLE_ADI")
	private String tapuMahalleAdi;
	
	@Column(name="TAPU_MULK_TIPI")
	private String tapuMulkTipi;
	
	@Column(name="TAPU_PARSEL")
	private String tapuParsel;
	
	@Column(name="TAPU_SAYFA_NO")
	private String tapuSayfaNo;
	
	@Column(name="TAPU_CILT_NO")
	private String tapuCiltNo;
	
	@Column(name="ARAC_PLAKA_NO")
	private String aracPlakaNo;
	
	@Column(name="ARAC_TIPI")
	private String aracAracTipi;
	
	@Column(name="BANKA_HESAP_NO")
	private String bankaHesapNo;
	
	@Column(name="MUHATAP_ADI")
	private String muhatapAdi;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="MUHATAP_ADRES_ID")
	private Adres muhatapAdresi;
	
	@Column(name="DIGER_BILGILER")
	private String digerBilgiler;
	
	@Column(name="MAL_TUTARI")
	private Float malTutari;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="ICRA_DOSYA_ID")
	private IcraDosyasi icraDosya;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="MAL_TIPI_ID")
	private MalTipi malTipi;
	
	@Column(name="MEVDUAT_BILGISI")
	private String mevduatBilgisi;

	}
