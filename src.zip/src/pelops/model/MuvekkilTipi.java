package pelops.model;

import javax.persistence.Column;
import javax.persistence.Table;

@Table(name="TNM_MUVEKKIL_TIPI")
public class MuvekkilTipi extends BaseEntity{
	
	@Column(name="UYAP_KODU")
	private String uyapKodu;
	
	@Column(name="ADI")
	private String adi;
		
}
