package pelops.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="TNM_TAKIP_TIPI")
public class TakipTipi extends BaseEntity{
	
	@Column(name="ADI")
	private String adi;

}
