package pelops.model;

public class TebligatListesi {

	private String tarih;
	
	private String icraDosyaNo;
	
	private String borcluAdi;
	
	private String konu;
	
	private String il;
	
	private Object brcd;
	
	private String icraBilgi;
	
	private String muameleTarihiTxt;
	
	
	

	public String getMuameleTarihiTxt() {
		return muameleTarihiTxt;
	}

	public void setMuameleTarihiTxt(String muameleTarihiTxt) {
		this.muameleTarihiTxt = muameleTarihiTxt;
	}

	public String getTarih() {
		return tarih;
	}

	public void setTarih(String tarih) {
		this.tarih = tarih;
	}

	public String getIcraDosyaNo() {
		return icraDosyaNo;
	}

	public void setIcraDosyaNo(String icraDosyaNo) {
		this.icraDosyaNo = icraDosyaNo;
	}

	public String getBorcluAdi() {
		return borcluAdi;
	}

	public void setBorcluAdi(String borcluAdi) {
		this.borcluAdi = borcluAdi;
	}

	public String getKonu() {
		return konu;
	}

	public void setKonu(String konu) {
		this.konu = konu;
	}

	public String getIl() {
		return il;
	}

	public void setIl(String il) {
		this.il = il;
	}

	public Object getBrcd() {
		return brcd;
	}

	public void setBrcd(Object brcd) {
		this.brcd = brcd;
	}

	public String getIcraBilgi() {
		return icraBilgi;
	}

	public void setIcraBilgi(String icraBilgi) {
		this.icraBilgi = icraBilgi;
	}
	
	
	
	
	
}
