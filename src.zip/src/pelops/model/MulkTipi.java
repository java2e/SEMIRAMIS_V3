package pelops.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="TNM_MULK_TIPI")
public class MulkTipi extends BaseEntity{
	
	@Column(name="ADI")
	private int adi;
	

}
