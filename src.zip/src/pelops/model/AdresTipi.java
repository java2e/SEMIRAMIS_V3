package pelops.model;

public class AdresTipi {

}
