package pelops.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="TNM_ETKINLIK")
public class Etkinlik extends BaseEntity{
	
	@Column(name="ACIKLAMA")
	private String aciklama;
	@Column(name="BAS_TARIH")
	private Date basTarih;
	@Column(name="BIT_TARIH")
	private Date bitTarih;	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="USER_ID")
	private User user;

}
