package pelops.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="TNM_HACIZ_TIPI")
public class HacizTipi extends BaseEntity{
	
	@Column(name="ADI")
	private String adi;

}
