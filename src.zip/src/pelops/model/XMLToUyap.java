package pelops.model;

public class XMLToUyap {

	String dosyaTuru;
	String takipTuru;
	String takipYolu;
	String takipSekli;
	String alacaklininTalepEttigiHak;
	String aciklama48e9;
	String BK84MaddeUygulansin;
	String BSMVUygulansin;
	String KKDFUygulansin;
	String dosyaBelirleyicisi;
	String dosyaTipi;
	
			String _taraf2_id;
					
					String __kisiKurumBilgileri2_id;
					String __kisiKurumBilgileri2_ad;
					
							String ___adres2_id;
							String ___adres2_ilKodu;
							String ___adres2_il;
							String ___adres2_ilce;
							String ___adres2_ilceKodu;
							String ___adres2_telefon;
							String ___adres2_cepTelefon;
							String ___adres2_elektronikPostaAdresi;
							String ___adres2_adresTuru;
							String ___adres2_adres;
							String ___adres2_postaKodu;
							String ___adres2_adresTuruAciklama;
							String ___kurum2_id;
							String ___kurum2_ticaretSicilNoVerildigiYer;
							String ___kurum2_harcDurumu;
							String ___kurum2_ticaretSicilNo;
							String ___kurum2_kurumAdi;
							String ___kurum2_kamuOzel;
							String ___kurum2_vergiDairesi;
							String ___kurum2_sskIsyeriSicilNo;
							String ___kurum2_vergiNo;
							
					
					String __rolTur2_rolID;
					String __rolTur2_Rol;
					String __ref2_id;
					String __ref2_to;
			
			
			String _taraf3_id;
			
					String __kisiKurumBilgileri3_id;
					String __kisiKurumBilgileri3_ad;
			
							String ___adres4_id;
							String ___adres4_ilKodu;
							String ___adres4_il;
							String ___adres4_ilce;
							String ___adres4_ilceKodu;
							String ___adres4_telefon;
							String ___adres4_cepTelefon;
							String ___adres4_elektronikPostaAdresi;
							String ___adres4_adresTuru;
							String ___adres4_adres;
							String ___adres4_postaKodu;
							String ___adres4_adresTuruAciklama;
							String ___kisiTumbilgileri3_id;
							String ___kisiTumbilgileri3_kayitNo;
							String ___kisiTumbilgileri3_soyadi;
							String ___kisiTumbilgileri3_ybnNfsKayitliOldgYer;
							String ___kisiTumbilgileri3_aileSiraNo;
							String ___kisiTumbilgileri3_cuzdanNo;
							String ___kisiTumbilgileri3_babaAdi;
							String ___kisiTumbilgileri3_anaAdi;
							String ___kisiTumbilgileri3_adi;
							String ___kisiTumbilgileri3_tcKimlikNo;
							String ___kisiTumbilgileri3_oncekiSoyadi;
							String ___kisiTumbilgileri3_ciltNo;
							String ___kisiTumbilgileri3_cuzdanSeriNo;
							String ___kisiTumbilgileri3_siraNo;
							String ___kisiTumbilgileri3_mahKoy;
							String ___kisiTumbilgileri3_dogumYeri;
							
					String __rolTur3_rolID;
					String __rolTur3_Rol;
			
			String _VekilKisi_id;
			
					String __vekil2_id;
					String __vekil2_kurumAvukatiMi;
					String __vekil2_avukatlikBuroAdi;
					String __vekil2_baroNo;
					String __vekil2_verigNo;
					String __kisiTumBilgileri2_id;
					String __kisiTumBilgileri2_kayitNo;
					String __kisiTumbilgileri2_soyadi;
					String __kisiTumbilgileri2_ybnNfsKayitliOldgYer;
					String __kisiTumbilgileri2_aileSiraNo;
					String __kisiTumbilgileri2_cuzdanNo;
					String __kisiTumbilgileri2_babaAdi;
					String __kisiTumbilgileri2_anaAdi;
					String __kisiTumbilgileri2_adi;
					String __kisiTumbilgileri2_tcKimlikNo;
					String __kisiTumbilgileri2_oncekiSoyadi;
					String __kisiTumbilgileri2_ciltNo;
					String __kisiTumbilgileri2_cuzdanSeriNo;
					String __kisiTumbilgileri2_siraNo;
					String __kisiTumbilgileri2_mahKoy;
					String __kisiTumbilgileri2_dogumYeri;
					String __adres3_id;
					String __adres3_ilKodu;
					String __adres3_il;
					String __adres3_ilce;
					String __adres3_ilceKodu;
					String __adres3_telefon;
					String __adres3_cepTelefon;
					String __adres3_adresTuru;
					String __adres3_adres;
					String __adres3_postakodu;
					String __adres3_adresTuruAciklama;
					
					
					
			String _digerAlacak_id;
			String _digerAlacak_tutarTur;
			String _digerAlacak_tutar;
			String _digerAlacak_tutar_tl;
			String _digerAlacak_alacakNo;
			String _digerAlacak_digerAlacakAciklama;
			String _digerAlacak_tutarAdi;
			String _digerAlacak_tarih;
	
					String __alacakKalemi2_id;
					String __alacakKalemi2_alacakKalemKod;
					String __alacakKalemi2_alacakKalemAdi;
					String __alacakKalemi2_alacakKalemTutar;
					String __alacakKalemi2_alacakKalemTutar_Tl;
					String __alacakKalemi2_alacakKalemIlkTutar;
					String __alacakKalemi2_tutarTur;
					String __alacakKalemi2_tutarAdi;
					String __alacakKalemi2_sabitTaksitTarihi;
					String __alacakKalemi2_dovizKurCevrimi;
					String __alacakKalemi2_akdiFaiz;
					String __alacakKalemi2_alacakKalemKodAciklama;
					String __alacakKalemi2_aciklama;
					String __alacakKalemi2_alacakKalemKodTuru;
					
							String ___alacakKalemi2_ref3_id;
							String ___alacakKalemi2_ref3_to;
							String ___alacakKalemi2_ref2_id;
							String ___alacakKalemi2_ref2_to;
							String ___alacakKalemi2_faiz2_id;
							String ___alacakKalemi2_faiz2_baslangicTarihi;
							String ___alacakKalemi2_faiz2_bitisTarihi;
							String ___alacakKalemi2_faiz2_faizOran;
							String ___alacakKalemi2_faiz2_faizTipKod;
							String ___alacakKalemi2_faiz2_faizTipKodAciklama;
							String ___alacakKalemi2_faiz_faizTutar;
							String ___alacakKalemi2_faiz_faizTutarAdi;
							String ___alacakKalemi2_faiz_faizSureTip;
				
				String __alacakKalemi3_id;
				String __alacakKalemi3_alacakKalemKod;
				String __alacakKalemi3_alacakKalemAdi;
				String __alacakKalemi3_alacakKalemTutar;
				String __alacakKalemi3_alacakKalemTutar_Tl;
				String __alacakKalemi3_alacakKalemIlkTutar;
				String __alacakKalemi3_alacakKalemIlkTip;
				String __alacakKalemi3_tutarTur;
				String __alacakKalemi3_tutarAdi;
				String __alacakKalemi3_sabitTaksitTarihi;
				String __alacakKalemi3_dovizKurCevrimi;
				String __alacakKalemi3_akdiFaiz;
				String __alacakKalemi3_alacakKalemKodAciklama;
				String __alacakKalemi3_aciklama;
				String __alacakKalemi3_alacakKalemKodTuru;
				

				String __alacakKalemi4_id;
				String __alacakKalemi4_alacakKalemKod;
				String __alacakKalemi4_alacakKalemAdi;
				String __alacakKalemi4_alacakKalemTutar;
				String __alacakKalemi4_alacakKalemTutar_Tl;
				String __alacakKalemi4_alacakKalemIlkTutar;
				String __alacakKalemi4_alacakKalemIlkTip;
				String __alacakKalemi4_tutarTur;
				String __alacakKalemi4_tutarAdi;
				String __alacakKalemi4_sabitTaksitTarihi;
				String __alacakKalemi4_dovizKurCevrimi;
				String __alacakKalemi4_akdiFaiz;
				String __alacakKalemi4_alacakKalemKodAciklama;
				String __alacakKalemi4_aciklama;
				String __alacakKalemi4_alacakKalemKodTuru;
				
				
				String __alacakKalemi5_id;
				String __alacakKalemi5_alacakKalemKod;
				String __alacakKalemi5_alacakKalemAdi;
				String __alacakKalemi5_alacakKalemTutar;
				String __alacakKalemi5_alacakKalemTutar_Tl;
				String __alacakKalemi5_alacakKalemIlkTutar;
				String __alacakKalemi5_alacakKalemIlkTip;
				String __alacakKalemi5_tutarTur;
				String __alacakKalemi5_tutarAdi;
				String __alacakKalemi5_sabitTaksitTarihi;
				String __alacakKalemi5_dovizKurCevrimi;
				String __alacakKalemi5_akdiFaiz;
				String __alacakKalemi5_alacakKalemKodAciklama;
				String __alacakKalemi5_aciklama;
				String __alacakKalemi5_alacakKalemKodTuru;
			
				
				
				
				
				public String get_digerAlacak_tutar_tl() {
					return _digerAlacak_tutar_tl;
				}
				public void set_digerAlacak_tutar_tl(String _digerAlacak_tutar_tl) {
					this._digerAlacak_tutar_tl = _digerAlacak_tutar_tl;
				}
				public String get__alacakKalemi2_alacakKalemTutar_Tl() {
					return __alacakKalemi2_alacakKalemTutar_Tl;
				}
				public void set__alacakKalemi2_alacakKalemTutar_Tl(
						String __alacakKalemi2_alacakKalemTutar_Tl) {
					this.__alacakKalemi2_alacakKalemTutar_Tl = __alacakKalemi2_alacakKalemTutar_Tl;
				}
				public String get__alacakKalemi3_alacakKalemTutar_Tl() {
					return __alacakKalemi3_alacakKalemTutar_Tl;
				}
				public void set__alacakKalemi3_alacakKalemTutar_Tl(
						String __alacakKalemi3_alacakKalemTutar_Tl) {
					this.__alacakKalemi3_alacakKalemTutar_Tl = __alacakKalemi3_alacakKalemTutar_Tl;
				}
				public String get__alacakKalemi4_alacakKalemTutar_Tl() {
					return __alacakKalemi4_alacakKalemTutar_Tl;
				}
				public void set__alacakKalemi4_alacakKalemTutar_Tl(
						String __alacakKalemi4_alacakKalemTutar_Tl) {
					this.__alacakKalemi4_alacakKalemTutar_Tl = __alacakKalemi4_alacakKalemTutar_Tl;
				}
				public String get__alacakKalemi5_alacakKalemTutar_Tl() {
					return __alacakKalemi5_alacakKalemTutar_Tl;
				}
				public void set__alacakKalemi5_alacakKalemTutar_Tl(
						String __alacakKalemi5_alacakKalemTutar_Tl) {
					this.__alacakKalemi5_alacakKalemTutar_Tl = __alacakKalemi5_alacakKalemTutar_Tl;
				}
				public String getDosyaTuru() {
					return dosyaTuru;
				}
				public void setDosyaTuru(String dosyaTuru) {
					this.dosyaTuru = dosyaTuru;
				}
				public String getTakipTuru() {
					return takipTuru;
				}
				public void setTakipTuru(String takipTuru) {
					this.takipTuru = takipTuru;
				}
				public String getTakipYolu() {
					return takipYolu;
				}
				public void setTakipYolu(String takipYolu) {
					this.takipYolu = takipYolu;
				}
				public String getTakipSekli() {
					return takipSekli;
				}
				public void setTakipSekli(String takipSekli) {
					this.takipSekli = takipSekli;
				}
				public String getAlacaklininTalepEttigiHak() {
					return alacaklininTalepEttigiHak;
				}
				public void setAlacaklininTalepEttigiHak(String alacaklininTalepEttigiHak) {
					this.alacaklininTalepEttigiHak = alacaklininTalepEttigiHak;
				}
				public String getAciklama48e9() {
					return aciklama48e9;
				}
				public void setAciklama48e9(String aciklama48e9) {
					this.aciklama48e9 = aciklama48e9;
				}
				public String getBK84MaddeUygulansin() {
					return BK84MaddeUygulansin;
				}
				public void setBK84MaddeUygulansin(String bK84MaddeUygulansin) {
					BK84MaddeUygulansin = bK84MaddeUygulansin;
				}
				public String getBSMVUygulansin() {
					return BSMVUygulansin;
				}
				public void setBSMVUygulansin(String bSMVUygulansin) {
					BSMVUygulansin = bSMVUygulansin;
				}
				public String getKKDFUygulansin() {
					return KKDFUygulansin;
				}
				public void setKKDFUygulansin(String kKDFUygulansin) {
					KKDFUygulansin = kKDFUygulansin;
				}
				public String getDosyaBelirleyicisi() {
					return dosyaBelirleyicisi;
				}
				public void setDosyaBelirleyicisi(String dosyaBelirleyicisi) {
					this.dosyaBelirleyicisi = dosyaBelirleyicisi;
				}
				public String getDosyaTipi() {
					return dosyaTipi;
				}
				public void setDosyaTipi(String dosyaTipi) {
					this.dosyaTipi = dosyaTipi;
				}
				public String get_taraf2_id() {
					return _taraf2_id;
				}
				public void set_taraf2_id(String _taraf2_id) {
					this._taraf2_id = _taraf2_id;
				}
				public String get__kisiKurumBilgileri2_id() {
					return __kisiKurumBilgileri2_id;
				}
				public void set__kisiKurumBilgileri2_id(String __kisiKurumBilgileri2_id) {
					this.__kisiKurumBilgileri2_id = __kisiKurumBilgileri2_id;
				}
				public String get__kisiKurumBilgileri2_ad() {
					return __kisiKurumBilgileri2_ad;
				}
				public void set__kisiKurumBilgileri2_ad(String __kisiKurumBilgileri2_ad) {
					this.__kisiKurumBilgileri2_ad = __kisiKurumBilgileri2_ad;
				}
				public String get___adres2_id() {
					return ___adres2_id;
				}
				public void set___adres2_id(String ___adres2_id) {
					this.___adres2_id = ___adres2_id;
				}
				public String get___adres2_ilKodu() {
					return ___adres2_ilKodu;
				}
				public void set___adres2_ilKodu(String ___adres2_ilKodu) {
					this.___adres2_ilKodu = ___adres2_ilKodu;
				}
				public String get___adres2_il() {
					return ___adres2_il;
				}
				public void set___adres2_il(String ___adres2_il) {
					this.___adres2_il = ___adres2_il;
				}
				public String get___adres2_ilce() {
					return ___adres2_ilce;
				}
				public void set___adres2_ilce(String ___adres2_ilce) {
					this.___adres2_ilce = ___adres2_ilce;
				}
				public String get___adres2_ilceKodu() {
					return ___adres2_ilceKodu;
				}
				public void set___adres2_ilceKodu(String ___adres2_ilceKodu) {
					this.___adres2_ilceKodu = ___adres2_ilceKodu;
				}
				public String get___adres2_telefon() {
					return ___adres2_telefon;
				}
				public void set___adres2_telefon(String ___adres2_telefon) {
					this.___adres2_telefon = ___adres2_telefon;
				}
				public String get___adres2_cepTelefon() {
					return ___adres2_cepTelefon;
				}
				public void set___adres2_cepTelefon(String ___adres2_cepTelefon) {
					this.___adres2_cepTelefon = ___adres2_cepTelefon;
				}
				public String get___adres2_elektronikPostaAdresi() {
					return ___adres2_elektronikPostaAdresi;
				}
				public void set___adres2_elektronikPostaAdresi(
						String ___adres2_elektronikPostaAdresi) {
					this.___adres2_elektronikPostaAdresi = ___adres2_elektronikPostaAdresi;
				}
				public String get___adres2_adresTuru() {
					return ___adres2_adresTuru;
				}
				public void set___adres2_adresTuru(String ___adres2_adresTuru) {
					this.___adres2_adresTuru = ___adres2_adresTuru;
				}
				public String get___adres2_adres() {
					return ___adres2_adres;
				}
				public void set___adres2_adres(String ___adres2_adres) {
					this.___adres2_adres = ___adres2_adres;
				}
				public String get___adres2_postaKodu() {
					return ___adres2_postaKodu;
				}
				public void set___adres2_postaKodu(String ___adres2_postaKodu) {
					this.___adres2_postaKodu = ___adres2_postaKodu;
				}
				public String get___adres2_adresTuruAciklama() {
					return ___adres2_adresTuruAciklama;
				}
				public void set___adres2_adresTuruAciklama(String ___adres2_adresTuruAciklama) {
					this.___adres2_adresTuruAciklama = ___adres2_adresTuruAciklama;
				}
				public String get___kurum2_id() {
					return ___kurum2_id;
				}
				public void set___kurum2_id(String ___kurum2_id) {
					this.___kurum2_id = ___kurum2_id;
				}
				public String get___kurum2_ticaretSicilNoVerildigiYer() {
					return ___kurum2_ticaretSicilNoVerildigiYer;
				}
				public void set___kurum2_ticaretSicilNoVerildigiYer(
						String ___kurum2_ticaretSicilNoVerildigiYer) {
					this.___kurum2_ticaretSicilNoVerildigiYer = ___kurum2_ticaretSicilNoVerildigiYer;
				}
				public String get___kurum2_harcDurumu() {
					return ___kurum2_harcDurumu;
				}
				public void set___kurum2_harcDurumu(String ___kurum2_harcDurumu) {
					this.___kurum2_harcDurumu = ___kurum2_harcDurumu;
				}
				public String get___kurum2_ticaretSicilNo() {
					return ___kurum2_ticaretSicilNo;
				}
				public void set___kurum2_ticaretSicilNo(String ___kurum2_ticaretSicilNo) {
					this.___kurum2_ticaretSicilNo = ___kurum2_ticaretSicilNo;
				}
				public String get___kurum2_kurumAdi() {
					return ___kurum2_kurumAdi;
				}
				public void set___kurum2_kurumAdi(String ___kurum2_kurumAdi) {
					this.___kurum2_kurumAdi = ___kurum2_kurumAdi;
				}
				public String get___kurum2_kamuOzel() {
					return ___kurum2_kamuOzel;
				}
				public void set___kurum2_kamuOzel(String ___kurum2_kamuOzel) {
					this.___kurum2_kamuOzel = ___kurum2_kamuOzel;
				}
				public String get___kurum2_vergiDairesi() {
					return ___kurum2_vergiDairesi;
				}
				public void set___kurum2_vergiDairesi(String ___kurum2_vergiDairesi) {
					this.___kurum2_vergiDairesi = ___kurum2_vergiDairesi;
				}
				public String get___kurum2_sskIsyeriSicilNo() {
					return ___kurum2_sskIsyeriSicilNo;
				}
				public void set___kurum2_sskIsyeriSicilNo(String ___kurum2_sskIsyeriSicilNo) {
					this.___kurum2_sskIsyeriSicilNo = ___kurum2_sskIsyeriSicilNo;
				}
				public String get___kurum2_vergiNo() {
					return ___kurum2_vergiNo;
				}
				public void set___kurum2_vergiNo(String ___kurum2_vergiNo) {
					this.___kurum2_vergiNo = ___kurum2_vergiNo;
				}
				public String get__rolTur2_rolID() {
					return __rolTur2_rolID;
				}
				public void set__rolTur2_rolID(String __rolTur2_rolID) {
					this.__rolTur2_rolID = __rolTur2_rolID;
				}
				public String get__rolTur2_Rol() {
					return __rolTur2_Rol;
				}
				public void set__rolTur2_Rol(String __rolTur2_Rol) {
					this.__rolTur2_Rol = __rolTur2_Rol;
				}
				public String get__ref2_id() {
					return __ref2_id;
				}
				public void set__ref2_id(String __ref2_id) {
					this.__ref2_id = __ref2_id;
				}
				public String get__ref2_to() {
					return __ref2_to;
				}
				public void set__ref2_to(String __ref2_to) {
					this.__ref2_to = __ref2_to;
				}
				public String get_taraf3_id() {
					return _taraf3_id;
				}
				public void set_taraf3_id(String _taraf3_id) {
					this._taraf3_id = _taraf3_id;
				}
				public String get__kisiKurumBilgileri3_id() {
					return __kisiKurumBilgileri3_id;
				}
				public void set__kisiKurumBilgileri3_id(String __kisiKurumBilgileri3_id) {
					this.__kisiKurumBilgileri3_id = __kisiKurumBilgileri3_id;
				}
				public String get__kisiKurumBilgileri3_ad() {
					return __kisiKurumBilgileri3_ad;
				}
				public void set__kisiKurumBilgileri3_ad(String __kisiKurumBilgileri3_ad) {
					this.__kisiKurumBilgileri3_ad = __kisiKurumBilgileri3_ad;
				}
				public String get___adres4_id() {
					return ___adres4_id;
				}
				public void set___adres4_id(String ___adres4_id) {
					this.___adres4_id = ___adres4_id;
				}
				public String get___adres4_ilKodu() {
					return ___adres4_ilKodu;
				}
				public void set___adres4_ilKodu(String ___adres4_ilKodu) {
					this.___adres4_ilKodu = ___adres4_ilKodu;
				}
				public String get___adres4_il() {
					return ___adres4_il;
				}
				public void set___adres4_il(String ___adres4_il) {
					this.___adres4_il = ___adres4_il;
				}
				public String get___adres4_ilce() {
					return ___adres4_ilce;
				}
				public void set___adres4_ilce(String ___adres4_ilce) {
					this.___adres4_ilce = ___adres4_ilce;
				}
				public String get___adres4_ilceKodu() {
					return ___adres4_ilceKodu;
				}
				public void set___adres4_ilceKodu(String ___adres4_ilceKodu) {
					this.___adres4_ilceKodu = ___adres4_ilceKodu;
				}
				public String get___adres4_telefon() {
					return ___adres4_telefon;
				}
				public void set___adres4_telefon(String ___adres4_telefon) {
					this.___adres4_telefon = ___adres4_telefon;
				}
				public String get___adres4_cepTelefon() {
					return ___adres4_cepTelefon;
				}
				public void set___adres4_cepTelefon(String ___adres4_cepTelefon) {
					this.___adres4_cepTelefon = ___adres4_cepTelefon;
				}
				public String get___adres4_elektronikPostaAdresi() {
					return ___adres4_elektronikPostaAdresi;
				}
				public void set___adres4_elektronikPostaAdresi(
						String ___adres4_elektronikPostaAdresi) {
					this.___adres4_elektronikPostaAdresi = ___adres4_elektronikPostaAdresi;
				}
				public String get___adres4_adresTuru() {
					return ___adres4_adresTuru;
				}
				public void set___adres4_adresTuru(String ___adres4_adresTuru) {
					this.___adres4_adresTuru = ___adres4_adresTuru;
				}
				public String get___adres4_adres() {
					return ___adres4_adres;
				}
				public void set___adres4_adres(String ___adres4_adres) {
					this.___adres4_adres = ___adres4_adres;
				}
				public String get___adres4_postaKodu() {
					return ___adres4_postaKodu;
				}
				public void set___adres4_postaKodu(String ___adres4_postaKodu) {
					this.___adres4_postaKodu = ___adres4_postaKodu;
				}
				public String get___adres4_adresTuruAciklama() {
					return ___adres4_adresTuruAciklama;
				}
				public void set___adres4_adresTuruAciklama(String ___adres4_adresTuruAciklama) {
					this.___adres4_adresTuruAciklama = ___adres4_adresTuruAciklama;
				}
				public String get___kisiTumbilgileri3_id() {
					return ___kisiTumbilgileri3_id;
				}
				public void set___kisiTumbilgileri3_id(String ___kisiTumbilgileri3_id) {
					this.___kisiTumbilgileri3_id = ___kisiTumbilgileri3_id;
				}
				public String get___kisiTumbilgileri3_kayitNo() {
					return ___kisiTumbilgileri3_kayitNo;
				}
				public void set___kisiTumbilgileri3_kayitNo(String ___kisiTumbilgileri3_kayitNo) {
					this.___kisiTumbilgileri3_kayitNo = ___kisiTumbilgileri3_kayitNo;
				}
				public String get___kisiTumbilgileri3_soyadi() {
					return ___kisiTumbilgileri3_soyadi;
				}
				public void set___kisiTumbilgileri3_soyadi(String ___kisiTumbilgileri3_soyadi) {
					this.___kisiTumbilgileri3_soyadi = ___kisiTumbilgileri3_soyadi;
				}
				public String get___kisiTumbilgileri3_ybnNfsKayitliOldgYer() {
					return ___kisiTumbilgileri3_ybnNfsKayitliOldgYer;
				}
				public void set___kisiTumbilgileri3_ybnNfsKayitliOldgYer(
						String ___kisiTumbilgileri3_ybnNfsKayitliOldgYer) {
					this.___kisiTumbilgileri3_ybnNfsKayitliOldgYer = ___kisiTumbilgileri3_ybnNfsKayitliOldgYer;
				}
				public String get___kisiTumbilgileri3_aileSiraNo() {
					return ___kisiTumbilgileri3_aileSiraNo;
				}
				public void set___kisiTumbilgileri3_aileSiraNo(
						String ___kisiTumbilgileri3_aileSiraNo) {
					this.___kisiTumbilgileri3_aileSiraNo = ___kisiTumbilgileri3_aileSiraNo;
				}
				public String get___kisiTumbilgileri3_cuzdanNo() {
					return ___kisiTumbilgileri3_cuzdanNo;
				}
				public void set___kisiTumbilgileri3_cuzdanNo(
						String ___kisiTumbilgileri3_cuzdanNo) {
					this.___kisiTumbilgileri3_cuzdanNo = ___kisiTumbilgileri3_cuzdanNo;
				}
				public String get___kisiTumbilgileri3_babaAdi() {
					return ___kisiTumbilgileri3_babaAdi;
				}
				public void set___kisiTumbilgileri3_babaAdi(String ___kisiTumbilgileri3_babaAdi) {
					this.___kisiTumbilgileri3_babaAdi = ___kisiTumbilgileri3_babaAdi;
				}
				public String get___kisiTumbilgileri3_anaAdi() {
					return ___kisiTumbilgileri3_anaAdi;
				}
				public void set___kisiTumbilgileri3_anaAdi(String ___kisiTumbilgileri3_anaAdi) {
					this.___kisiTumbilgileri3_anaAdi = ___kisiTumbilgileri3_anaAdi;
				}
				public String get___kisiTumbilgileri3_adi() {
					return ___kisiTumbilgileri3_adi;
				}
				public void set___kisiTumbilgileri3_adi(String ___kisiTumbilgileri3_adi) {
					this.___kisiTumbilgileri3_adi = ___kisiTumbilgileri3_adi;
				}
				public String get___kisiTumbilgileri3_tcKimlikNo() {
					return ___kisiTumbilgileri3_tcKimlikNo;
				}
				public void set___kisiTumbilgileri3_tcKimlikNo(
						String ___kisiTumbilgileri3_tcKimlikNo) {
					this.___kisiTumbilgileri3_tcKimlikNo = ___kisiTumbilgileri3_tcKimlikNo;
				}
				public String get___kisiTumbilgileri3_oncekiSoyadi() {
					return ___kisiTumbilgileri3_oncekiSoyadi;
				}
				public void set___kisiTumbilgileri3_oncekiSoyadi(
						String ___kisiTumbilgileri3_oncekiSoyadi) {
					this.___kisiTumbilgileri3_oncekiSoyadi = ___kisiTumbilgileri3_oncekiSoyadi;
				}
				public String get___kisiTumbilgileri3_ciltNo() {
					return ___kisiTumbilgileri3_ciltNo;
				}
				public void set___kisiTumbilgileri3_ciltNo(String ___kisiTumbilgileri3_ciltNo) {
					this.___kisiTumbilgileri3_ciltNo = ___kisiTumbilgileri3_ciltNo;
				}
				public String get___kisiTumbilgileri3_cuzdanSeriNo() {
					return ___kisiTumbilgileri3_cuzdanSeriNo;
				}
				public void set___kisiTumbilgileri3_cuzdanSeriNo(
						String ___kisiTumbilgileri3_cuzdanSeriNo) {
					this.___kisiTumbilgileri3_cuzdanSeriNo = ___kisiTumbilgileri3_cuzdanSeriNo;
				}
				public String get___kisiTumbilgileri3_siraNo() {
					return ___kisiTumbilgileri3_siraNo;
				}
				public void set___kisiTumbilgileri3_siraNo(String ___kisiTumbilgileri3_siraNo) {
					this.___kisiTumbilgileri3_siraNo = ___kisiTumbilgileri3_siraNo;
				}
				public String get___kisiTumbilgileri3_mahKoy() {
					return ___kisiTumbilgileri3_mahKoy;
				}
				public void set___kisiTumbilgileri3_mahKoy(String ___kisiTumbilgileri3_mahKoy) {
					this.___kisiTumbilgileri3_mahKoy = ___kisiTumbilgileri3_mahKoy;
				}
				public String get___kisiTumbilgileri3_dogumYeri() {
					return ___kisiTumbilgileri3_dogumYeri;
				}
				public void set___kisiTumbilgileri3_dogumYeri(
						String ___kisiTumbilgileri3_dogumYeri) {
					this.___kisiTumbilgileri3_dogumYeri = ___kisiTumbilgileri3_dogumYeri;
				}
				public String get__rolTur3_rolID() {
					return __rolTur3_rolID;
				}
				public void set__rolTur3_rolID(String __rolTur3_rolID) {
					this.__rolTur3_rolID = __rolTur3_rolID;
				}
				public String get__rolTur3_Rol() {
					return __rolTur3_Rol;
				}
				public void set__rolTur3_Rol(String __rolTur3_Rol) {
					this.__rolTur3_Rol = __rolTur3_Rol;
				}
				public String get_VekilKisi_id() {
					return _VekilKisi_id;
				}
				public void set_VekilKisi_id(String _VekilKisi_id) {
					this._VekilKisi_id = _VekilKisi_id;
				}
				public String get__vekil2_id() {
					return __vekil2_id;
				}
				public void set__vekil2_id(String __vekil2_id) {
					this.__vekil2_id = __vekil2_id;
				}
				public String get__vekil2_kurumAvukatiMi() {
					return __vekil2_kurumAvukatiMi;
				}
				public void set__vekil2_kurumAvukatiMi(String __vekil2_kurumAvukatiMi) {
					this.__vekil2_kurumAvukatiMi = __vekil2_kurumAvukatiMi;
				}
				public String get__vekil2_avukatlikBuroAdi() {
					return __vekil2_avukatlikBuroAdi;
				}
				public void set__vekil2_avukatlikBuroAdi(String __vekil2_avukatlikBuroAdi) {
					this.__vekil2_avukatlikBuroAdi = __vekil2_avukatlikBuroAdi;
				}
				public String get__vekil2_baroNo() {
					return __vekil2_baroNo;
				}
				public void set__vekil2_baroNo(String __vekil2_baroNo) {
					this.__vekil2_baroNo = __vekil2_baroNo;
				}
				public String get__vekil2_verigNo() {
					return __vekil2_verigNo;
				}
				public void set__vekil2_verigNo(String __vekil2_verigNo) {
					this.__vekil2_verigNo = __vekil2_verigNo;
				}
				public String get__kisiTumBilgileri2_id() {
					return __kisiTumBilgileri2_id;
				}
				public void set__kisiTumBilgileri2_id(String __kisiTumBilgileri2_id) {
					this.__kisiTumBilgileri2_id = __kisiTumBilgileri2_id;
				}
				public String get__kisiTumBilgileri2_kayitNo() {
					return __kisiTumBilgileri2_kayitNo;
				}
				public void set__kisiTumBilgileri2_kayitNo(String __kisiTumBilgileri2_kayitNo) {
					this.__kisiTumBilgileri2_kayitNo = __kisiTumBilgileri2_kayitNo;
				}
				public String get__kisiTumbilgileri2_soyadi() {
					return __kisiTumbilgileri2_soyadi;
				}
				public void set__kisiTumbilgileri2_soyadi(String __kisiTumbilgileri2_soyadi) {
					this.__kisiTumbilgileri2_soyadi = __kisiTumbilgileri2_soyadi;
				}
				public String get__kisiTumbilgileri2_ybnNfsKayitliOldgYer() {
					return __kisiTumbilgileri2_ybnNfsKayitliOldgYer;
				}
				public void set__kisiTumbilgileri2_ybnNfsKayitliOldgYer(
						String __kisiTumbilgileri2_ybnNfsKayitliOldgYer) {
					this.__kisiTumbilgileri2_ybnNfsKayitliOldgYer = __kisiTumbilgileri2_ybnNfsKayitliOldgYer;
				}
				public String get__kisiTumbilgileri2_aileSiraNo() {
					return __kisiTumbilgileri2_aileSiraNo;
				}
				public void set__kisiTumbilgileri2_aileSiraNo(
						String __kisiTumbilgileri2_aileSiraNo) {
					this.__kisiTumbilgileri2_aileSiraNo = __kisiTumbilgileri2_aileSiraNo;
				}
				public String get__kisiTumbilgileri2_cuzdanNo() {
					return __kisiTumbilgileri2_cuzdanNo;
				}
				public void set__kisiTumbilgileri2_cuzdanNo(String __kisiTumbilgileri2_cuzdanNo) {
					this.__kisiTumbilgileri2_cuzdanNo = __kisiTumbilgileri2_cuzdanNo;
				}
				public String get__kisiTumbilgileri2_babaAdi() {
					return __kisiTumbilgileri2_babaAdi;
				}
				public void set__kisiTumbilgileri2_babaAdi(String __kisiTumbilgileri2_babaAdi) {
					this.__kisiTumbilgileri2_babaAdi = __kisiTumbilgileri2_babaAdi;
				}
				public String get__kisiTumbilgileri2_anaAdi() {
					return __kisiTumbilgileri2_anaAdi;
				}
				public void set__kisiTumbilgileri2_anaAdi(String __kisiTumbilgileri2_anaAdi) {
					this.__kisiTumbilgileri2_anaAdi = __kisiTumbilgileri2_anaAdi;
				}
				public String get__kisiTumbilgileri2_adi() {
					return __kisiTumbilgileri2_adi;
				}
				public void set__kisiTumbilgileri2_adi(String __kisiTumbilgileri2_adi) {
					this.__kisiTumbilgileri2_adi = __kisiTumbilgileri2_adi;
				}
				public String get__kisiTumbilgileri2_tcKimlikNo() {
					return __kisiTumbilgileri2_tcKimlikNo;
				}
				public void set__kisiTumbilgileri2_tcKimlikNo(
						String __kisiTumbilgileri2_tcKimlikNo) {
					this.__kisiTumbilgileri2_tcKimlikNo = __kisiTumbilgileri2_tcKimlikNo;
				}
				public String get__kisiTumbilgileri2_oncekiSoyadi() {
					return __kisiTumbilgileri2_oncekiSoyadi;
				}
				public void set__kisiTumbilgileri2_oncekiSoyadi(
						String __kisiTumbilgileri2_oncekiSoyadi) {
					this.__kisiTumbilgileri2_oncekiSoyadi = __kisiTumbilgileri2_oncekiSoyadi;
				}
				public String get__kisiTumbilgileri2_ciltNo() {
					return __kisiTumbilgileri2_ciltNo;
				}
				public void set__kisiTumbilgileri2_ciltNo(String __kisiTumbilgileri2_ciltNo) {
					this.__kisiTumbilgileri2_ciltNo = __kisiTumbilgileri2_ciltNo;
				}
				public String get__kisiTumbilgileri2_cuzdanSeriNo() {
					return __kisiTumbilgileri2_cuzdanSeriNo;
				}
				public void set__kisiTumbilgileri2_cuzdanSeriNo(
						String __kisiTumbilgileri2_cuzdanSeriNo) {
					this.__kisiTumbilgileri2_cuzdanSeriNo = __kisiTumbilgileri2_cuzdanSeriNo;
				}
				public String get__kisiTumbilgileri2_siraNo() {
					return __kisiTumbilgileri2_siraNo;
				}
				public void set__kisiTumbilgileri2_siraNo(String __kisiTumbilgileri2_siraNo) {
					this.__kisiTumbilgileri2_siraNo = __kisiTumbilgileri2_siraNo;
				}
				public String get__kisiTumbilgileri2_mahKoy() {
					return __kisiTumbilgileri2_mahKoy;
				}
				public void set__kisiTumbilgileri2_mahKoy(String __kisiTumbilgileri2_mahKoy) {
					this.__kisiTumbilgileri2_mahKoy = __kisiTumbilgileri2_mahKoy;
				}
				public String get__kisiTumbilgileri2_dogumYeri() {
					return __kisiTumbilgileri2_dogumYeri;
				}
				public void set__kisiTumbilgileri2_dogumYeri(
						String __kisiTumbilgileri2_dogumYeri) {
					this.__kisiTumbilgileri2_dogumYeri = __kisiTumbilgileri2_dogumYeri;
				}
				public String get__adres3_id() {
					return __adres3_id;
				}
				public void set__adres3_id(String __adres3_id) {
					this.__adres3_id = __adres3_id;
				}
				public String get__adres3_ilKodu() {
					return __adres3_ilKodu;
				}
				public void set__adres3_ilKodu(String __adres3_ilKodu) {
					this.__adres3_ilKodu = __adres3_ilKodu;
				}
				public String get__adres3_il() {
					return __adres3_il;
				}
				public void set__adres3_il(String __adres3_il) {
					this.__adres3_il = __adres3_il;
				}
				public String get__adres3_ilce() {
					return __adres3_ilce;
				}
				public void set__adres3_ilce(String __adres3_ilce) {
					this.__adres3_ilce = __adres3_ilce;
				}
				public String get__adres3_ilceKodu() {
					return __adres3_ilceKodu;
				}
				public void set__adres3_ilceKodu(String __adres3_ilceKodu) {
					this.__adres3_ilceKodu = __adres3_ilceKodu;
				}
				public String get__adres3_telefon() {
					return __adres3_telefon;
				}
				public void set__adres3_telefon(String __adres3_telefon) {
					this.__adres3_telefon = __adres3_telefon;
				}
				public String get__adres3_cepTelefon() {
					return __adres3_cepTelefon;
				}
				public void set__adres3_cepTelefon(String __adres3_cepTelefon) {
					this.__adres3_cepTelefon = __adres3_cepTelefon;
				}
				public String get__adres3_adresTuru() {
					return __adres3_adresTuru;
				}
				public void set__adres3_adresTuru(String __adres3_adresTuru) {
					this.__adres3_adresTuru = __adres3_adresTuru;
				}
				public String get__adres3_adres() {
					return __adres3_adres;
				}
				public void set__adres3_adres(String __adres3_adres) {
					this.__adres3_adres = __adres3_adres;
				}
				public String get__adres3_postakodu() {
					return __adres3_postakodu;
				}
				public void set__adres3_postakodu(String __adres3_postakodu) {
					this.__adres3_postakodu = __adres3_postakodu;
				}
				public String get__adres3_adresTuruAciklama() {
					return __adres3_adresTuruAciklama;
				}
				public void set__adres3_adresTuruAciklama(String __adres3_adresTuruAciklama) {
					this.__adres3_adresTuruAciklama = __adres3_adresTuruAciklama;
				}
				public String get_digerAlacak_id() {
					return _digerAlacak_id;
				}
				public void set_digerAlacak_id(String _digerAlacak_id) {
					this._digerAlacak_id = _digerAlacak_id;
				}
				public String get_digerAlacak_tutarTur() {
					return _digerAlacak_tutarTur;
				}
				public void set_digerAlacak_tutarTur(String _digerAlacak_tutarTur) {
					this._digerAlacak_tutarTur = _digerAlacak_tutarTur;
				}
				public String get_digerAlacak_tutar() {
					return _digerAlacak_tutar;
				}
				public void set_digerAlacak_tutar(String _digerAlacak_tutar) {
					this._digerAlacak_tutar = _digerAlacak_tutar;
				}
				public String get_digerAlacak_alacakNo() {
					return _digerAlacak_alacakNo;
				}
				public void set_digerAlacak_alacakNo(String _digerAlacak_alacakNo) {
					this._digerAlacak_alacakNo = _digerAlacak_alacakNo;
				}
				public String get_digerAlacak_digerAlacakAciklama() {
					return _digerAlacak_digerAlacakAciklama;
				}
				public void set_digerAlacak_digerAlacakAciklama(
						String _digerAlacak_digerAlacakAciklama) {
					this._digerAlacak_digerAlacakAciklama = _digerAlacak_digerAlacakAciklama;
				}
				public String get_digerAlacak_tutarAdi() {
					return _digerAlacak_tutarAdi;
				}
				public void set_digerAlacak_tutarAdi(String _digerAlacak_tutarAdi) {
					this._digerAlacak_tutarAdi = _digerAlacak_tutarAdi;
				}
				public String get_digerAlacak_tarih() {
					return _digerAlacak_tarih;
				}
				public void set_digerAlacak_tarih(String _digerAlacak_tarih) {
					this._digerAlacak_tarih = _digerAlacak_tarih;
				}
				public String get__alacakKalemi2_id() {
					return __alacakKalemi2_id;
				}
				public void set__alacakKalemi2_id(String __alacakKalemi2_id) {
					this.__alacakKalemi2_id = __alacakKalemi2_id;
				}
				public String get__alacakKalemi2_alacakKalemKod() {
					return __alacakKalemi2_alacakKalemKod;
				}
				public void set__alacakKalemi2_alacakKalemKod(
						String __alacakKalemi2_alacakKalemKod) {
					this.__alacakKalemi2_alacakKalemKod = __alacakKalemi2_alacakKalemKod;
				}
				public String get__alacakKalemi2_alacakKalemAdi() {
					return __alacakKalemi2_alacakKalemAdi;
				}
				public void set__alacakKalemi2_alacakKalemAdi(
						String __alacakKalemi2_alacakKalemAdi) {
					this.__alacakKalemi2_alacakKalemAdi = __alacakKalemi2_alacakKalemAdi;
				}
				public String get__alacakKalemi2_alacakKalemTutar() {
					return __alacakKalemi2_alacakKalemTutar;
				}
				public void set__alacakKalemi2_alacakKalemTutar(
						String __alacakKalemi2_alacakKalemTutar) {
					this.__alacakKalemi2_alacakKalemTutar = __alacakKalemi2_alacakKalemTutar;
				}
				public String get__alacakKalemi2_alacakKalemIlkTutar() {
					return __alacakKalemi2_alacakKalemIlkTutar;
				}
				public void set__alacakKalemi2_alacakKalemIlkTutar(
						String __alacakKalemi2_alacakKalemIlkTutar) {
					this.__alacakKalemi2_alacakKalemIlkTutar = __alacakKalemi2_alacakKalemIlkTutar;
				}
				public String get__alacakKalemi2_tutarTur() {
					return __alacakKalemi2_tutarTur;
				}
				public void set__alacakKalemi2_tutarTur(String __alacakKalemi2_tutarTur) {
					this.__alacakKalemi2_tutarTur = __alacakKalemi2_tutarTur;
				}
				public String get__alacakKalemi2_tutarAdi() {
					return __alacakKalemi2_tutarAdi;
				}
				public void set__alacakKalemi2_tutarAdi(String __alacakKalemi2_tutarAdi) {
					this.__alacakKalemi2_tutarAdi = __alacakKalemi2_tutarAdi;
				}
				public String get__alacakKalemi2_sabitTaksitTarihi() {
					return __alacakKalemi2_sabitTaksitTarihi;
				}
				public void set__alacakKalemi2_sabitTaksitTarihi(
						String __alacakKalemi2_sabitTaksitTarihi) {
					this.__alacakKalemi2_sabitTaksitTarihi = __alacakKalemi2_sabitTaksitTarihi;
				}
				public String get__alacakKalemi2_dovizKurCevrimi() {
					return __alacakKalemi2_dovizKurCevrimi;
				}
				public void set__alacakKalemi2_dovizKurCevrimi(
						String __alacakKalemi2_dovizKurCevrimi) {
					this.__alacakKalemi2_dovizKurCevrimi = __alacakKalemi2_dovizKurCevrimi;
				}
				public String get__alacakKalemi2_akdiFaiz() {
					return __alacakKalemi2_akdiFaiz;
				}
				public void set__alacakKalemi2_akdiFaiz(String __alacakKalemi2_akdiFaiz) {
					this.__alacakKalemi2_akdiFaiz = __alacakKalemi2_akdiFaiz;
				}
				public String get__alacakKalemi2_alacakKalemKodAciklama() {
					return __alacakKalemi2_alacakKalemKodAciklama;
				}
				public void set__alacakKalemi2_alacakKalemKodAciklama(
						String __alacakKalemi2_alacakKalemKodAciklama) {
					this.__alacakKalemi2_alacakKalemKodAciklama = __alacakKalemi2_alacakKalemKodAciklama;
				}
				public String get__alacakKalemi2_aciklama() {
					return __alacakKalemi2_aciklama;
				}
				public void set__alacakKalemi2_aciklama(String __alacakKalemi2_aciklama) {
					this.__alacakKalemi2_aciklama = __alacakKalemi2_aciklama;
				}
				public String get__alacakKalemi2_alacakKalemKodTuru() {
					return __alacakKalemi2_alacakKalemKodTuru;
				}
				public void set__alacakKalemi2_alacakKalemKodTuru(
						String __alacakKalemi2_alacakKalemKodTuru) {
					this.__alacakKalemi2_alacakKalemKodTuru = __alacakKalemi2_alacakKalemKodTuru;
				}
				public String get___alacakKalemi2_ref3_id() {
					return ___alacakKalemi2_ref3_id;
				}
				public void set___alacakKalemi2_ref3_id(String ___alacakKalemi2_ref3_id) {
					this.___alacakKalemi2_ref3_id = ___alacakKalemi2_ref3_id;
				}
				public String get___alacakKalemi2_ref3_to() {
					return ___alacakKalemi2_ref3_to;
				}
				public void set___alacakKalemi2_ref3_to(String ___alacakKalemi2_ref3_to) {
					this.___alacakKalemi2_ref3_to = ___alacakKalemi2_ref3_to;
				}
				public String get___alacakKalemi2_ref2_id() {
					return ___alacakKalemi2_ref2_id;
				}
				public void set___alacakKalemi2_ref2_id(String ___alacakKalemi2_ref2_id) {
					this.___alacakKalemi2_ref2_id = ___alacakKalemi2_ref2_id;
				}
				public String get___alacakKalemi2_ref2_to() {
					return ___alacakKalemi2_ref2_to;
				}
				public void set___alacakKalemi2_ref2_to(String ___alacakKalemi2_ref2_to) {
					this.___alacakKalemi2_ref2_to = ___alacakKalemi2_ref2_to;
				}
				public String get___alacakKalemi2_faiz2_id() {
					return ___alacakKalemi2_faiz2_id;
				}
				public void set___alacakKalemi2_faiz2_id(String ___alacakKalemi2_faiz2_id) {
					this.___alacakKalemi2_faiz2_id = ___alacakKalemi2_faiz2_id;
				}
				public String get___alacakKalemi2_faiz2_baslangicTarihi() {
					return ___alacakKalemi2_faiz2_baslangicTarihi;
				}
				public void set___alacakKalemi2_faiz2_baslangicTarihi(
						String ___alacakKalemi2_faiz2_baslangicTarihi) {
					this.___alacakKalemi2_faiz2_baslangicTarihi = ___alacakKalemi2_faiz2_baslangicTarihi;
				}
				public String get___alacakKalemi2_faiz2_bitisTarihi() {
					return ___alacakKalemi2_faiz2_bitisTarihi;
				}
				public void set___alacakKalemi2_faiz2_bitisTarihi(
						String ___alacakKalemi2_faiz2_bitisTarihi) {
					this.___alacakKalemi2_faiz2_bitisTarihi = ___alacakKalemi2_faiz2_bitisTarihi;
				}
				public String get___alacakKalemi2_faiz2_faizOran() {
					return ___alacakKalemi2_faiz2_faizOran;
				}
				public void set___alacakKalemi2_faiz2_faizOran(
						String ___alacakKalemi2_faiz2_faizOran) {
					this.___alacakKalemi2_faiz2_faizOran = ___alacakKalemi2_faiz2_faizOran;
				}
				public String get___alacakKalemi2_faiz2_faizTipKod() {
					return ___alacakKalemi2_faiz2_faizTipKod;
				}
				public void set___alacakKalemi2_faiz2_faizTipKod(
						String ___alacakKalemi2_faiz2_faizTipKod) {
					this.___alacakKalemi2_faiz2_faizTipKod = ___alacakKalemi2_faiz2_faizTipKod;
				}
				public String get___alacakKalemi2_faiz2_faizTipKodAciklama() {
					return ___alacakKalemi2_faiz2_faizTipKodAciklama;
				}
				public void set___alacakKalemi2_faiz2_faizTipKodAciklama(
						String ___alacakKalemi2_faiz2_faizTipKodAciklama) {
					this.___alacakKalemi2_faiz2_faizTipKodAciklama = ___alacakKalemi2_faiz2_faizTipKodAciklama;
				}
				public String get___alacakKalemi2_faiz_faizTutar() {
					return ___alacakKalemi2_faiz_faizTutar;
				}
				public void set___alacakKalemi2_faiz_faizTutar(
						String ___alacakKalemi2_faiz_faizTutar) {
					this.___alacakKalemi2_faiz_faizTutar = ___alacakKalemi2_faiz_faizTutar;
				}
				public String get___alacakKalemi2_faiz_faizTutarAdi() {
					return ___alacakKalemi2_faiz_faizTutarAdi;
				}
				public void set___alacakKalemi2_faiz_faizTutarAdi(
						String ___alacakKalemi2_faiz_faizTutarAdi) {
					this.___alacakKalemi2_faiz_faizTutarAdi = ___alacakKalemi2_faiz_faizTutarAdi;
				}
				public String get___alacakKalemi2_faiz_faizSureTip() {
					return ___alacakKalemi2_faiz_faizSureTip;
				}
				public void set___alacakKalemi2_faiz_faizSureTip(
						String ___alacakKalemi2_faiz_faizSureTip) {
					this.___alacakKalemi2_faiz_faizSureTip = ___alacakKalemi2_faiz_faizSureTip;
				}
				public String get__alacakKalemi3_id() {
					return __alacakKalemi3_id;
				}
				public void set__alacakKalemi3_id(String __alacakKalemi3_id) {
					this.__alacakKalemi3_id = __alacakKalemi3_id;
				}
				public String get__alacakKalemi3_alacakKalemKod() {
					return __alacakKalemi3_alacakKalemKod;
				}
				public void set__alacakKalemi3_alacakKalemKod(
						String __alacakKalemi3_alacakKalemKod) {
					this.__alacakKalemi3_alacakKalemKod = __alacakKalemi3_alacakKalemKod;
				}
				public String get__alacakKalemi3_alacakKalemAdi() {
					return __alacakKalemi3_alacakKalemAdi;
				}
				public void set__alacakKalemi3_alacakKalemAdi(
						String __alacakKalemi3_alacakKalemAdi) {
					this.__alacakKalemi3_alacakKalemAdi = __alacakKalemi3_alacakKalemAdi;
				}
				public String get__alacakKalemi3_alacakKalemTutar() {
					return __alacakKalemi3_alacakKalemTutar;
				}
				public void set__alacakKalemi3_alacakKalemTutar(
						String __alacakKalemi3_alacakKalemTutar) {
					this.__alacakKalemi3_alacakKalemTutar = __alacakKalemi3_alacakKalemTutar;
				}
				public String get__alacakKalemi3_alacakKalemIlkTutar() {
					return __alacakKalemi3_alacakKalemIlkTutar;
				}
				public void set__alacakKalemi3_alacakKalemIlkTutar(
						String __alacakKalemi3_alacakKalemIlkTutar) {
					this.__alacakKalemi3_alacakKalemIlkTutar = __alacakKalemi3_alacakKalemIlkTutar;
				}
				public String get__alacakKalemi3_alacakKalemIlkTip() {
					return __alacakKalemi3_alacakKalemIlkTip;
				}
				public void set__alacakKalemi3_alacakKalemIlkTip(
						String __alacakKalemi3_alacakKalemIlkTip) {
					this.__alacakKalemi3_alacakKalemIlkTip = __alacakKalemi3_alacakKalemIlkTip;
				}
				public String get__alacakKalemi3_tutarTur() {
					return __alacakKalemi3_tutarTur;
				}
				public void set__alacakKalemi3_tutarTur(String __alacakKalemi3_tutarTur) {
					this.__alacakKalemi3_tutarTur = __alacakKalemi3_tutarTur;
				}
				public String get__alacakKalemi3_tutarAdi() {
					return __alacakKalemi3_tutarAdi;
				}
				public void set__alacakKalemi3_tutarAdi(String __alacakKalemi3_tutarAdi) {
					this.__alacakKalemi3_tutarAdi = __alacakKalemi3_tutarAdi;
				}
				public String get__alacakKalemi3_sabitTaksitTarihi() {
					return __alacakKalemi3_sabitTaksitTarihi;
				}
				public void set__alacakKalemi3_sabitTaksitTarihi(
						String __alacakKalemi3_sabitTaksitTarihi) {
					this.__alacakKalemi3_sabitTaksitTarihi = __alacakKalemi3_sabitTaksitTarihi;
				}
				public String get__alacakKalemi3_dovizKurCevrimi() {
					return __alacakKalemi3_dovizKurCevrimi;
				}
				public void set__alacakKalemi3_dovizKurCevrimi(
						String __alacakKalemi3_dovizKurCevrimi) {
					this.__alacakKalemi3_dovizKurCevrimi = __alacakKalemi3_dovizKurCevrimi;
				}
				public String get__alacakKalemi3_akdiFaiz() {
					return __alacakKalemi3_akdiFaiz;
				}
				public void set__alacakKalemi3_akdiFaiz(String __alacakKalemi3_akdiFaiz) {
					this.__alacakKalemi3_akdiFaiz = __alacakKalemi3_akdiFaiz;
				}
				public String get__alacakKalemi3_alacakKalemKodAciklama() {
					return __alacakKalemi3_alacakKalemKodAciklama;
				}
				public void set__alacakKalemi3_alacakKalemKodAciklama(
						String __alacakKalemi3_alacakKalemKodAciklama) {
					this.__alacakKalemi3_alacakKalemKodAciklama = __alacakKalemi3_alacakKalemKodAciklama;
				}
				public String get__alacakKalemi3_aciklama() {
					return __alacakKalemi3_aciklama;
				}
				public void set__alacakKalemi3_aciklama(String __alacakKalemi3_aciklama) {
					this.__alacakKalemi3_aciklama = __alacakKalemi3_aciklama;
				}
				public String get__alacakKalemi3_alacakKalemKodTuru() {
					return __alacakKalemi3_alacakKalemKodTuru;
				}
				public void set__alacakKalemi3_alacakKalemKodTuru(
						String __alacakKalemi3_alacakKalemKodTuru) {
					this.__alacakKalemi3_alacakKalemKodTuru = __alacakKalemi3_alacakKalemKodTuru;
				}
				public String get__alacakKalemi4_id() {
					return __alacakKalemi4_id;
				}
				public void set__alacakKalemi4_id(String __alacakKalemi4_id) {
					this.__alacakKalemi4_id = __alacakKalemi4_id;
				}
				public String get__alacakKalemi4_alacakKalemKod() {
					return __alacakKalemi4_alacakKalemKod;
				}
				public void set__alacakKalemi4_alacakKalemKod(
						String __alacakKalemi4_alacakKalemKod) {
					this.__alacakKalemi4_alacakKalemKod = __alacakKalemi4_alacakKalemKod;
				}
				public String get__alacakKalemi4_alacakKalemAdi() {
					return __alacakKalemi4_alacakKalemAdi;
				}
				public void set__alacakKalemi4_alacakKalemAdi(
						String __alacakKalemi4_alacakKalemAdi) {
					this.__alacakKalemi4_alacakKalemAdi = __alacakKalemi4_alacakKalemAdi;
				}
				public String get__alacakKalemi4_alacakKalemTutar() {
					return __alacakKalemi4_alacakKalemTutar;
				}
				public void set__alacakKalemi4_alacakKalemTutar(
						String __alacakKalemi4_alacakKalemTutar) {
					this.__alacakKalemi4_alacakKalemTutar = __alacakKalemi4_alacakKalemTutar;
				}
				public String get__alacakKalemi4_alacakKalemIlkTutar() {
					return __alacakKalemi4_alacakKalemIlkTutar;
				}
				public void set__alacakKalemi4_alacakKalemIlkTutar(
						String __alacakKalemi4_alacakKalemIlkTutar) {
					this.__alacakKalemi4_alacakKalemIlkTutar = __alacakKalemi4_alacakKalemIlkTutar;
				}
				public String get__alacakKalemi4_alacakKalemIlkTip() {
					return __alacakKalemi4_alacakKalemIlkTip;
				}
				public void set__alacakKalemi4_alacakKalemIlkTip(
						String __alacakKalemi4_alacakKalemIlkTip) {
					this.__alacakKalemi4_alacakKalemIlkTip = __alacakKalemi4_alacakKalemIlkTip;
				}
				public String get__alacakKalemi4_tutarTur() {
					return __alacakKalemi4_tutarTur;
				}
				public void set__alacakKalemi4_tutarTur(String __alacakKalemi4_tutarTur) {
					this.__alacakKalemi4_tutarTur = __alacakKalemi4_tutarTur;
				}
				public String get__alacakKalemi4_tutarAdi() {
					return __alacakKalemi4_tutarAdi;
				}
				public void set__alacakKalemi4_tutarAdi(String __alacakKalemi4_tutarAdi) {
					this.__alacakKalemi4_tutarAdi = __alacakKalemi4_tutarAdi;
				}
				public String get__alacakKalemi4_sabitTaksitTarihi() {
					return __alacakKalemi4_sabitTaksitTarihi;
				}
				public void set__alacakKalemi4_sabitTaksitTarihi(
						String __alacakKalemi4_sabitTaksitTarihi) {
					this.__alacakKalemi4_sabitTaksitTarihi = __alacakKalemi4_sabitTaksitTarihi;
				}
				public String get__alacakKalemi4_dovizKurCevrimi() {
					return __alacakKalemi4_dovizKurCevrimi;
				}
				public void set__alacakKalemi4_dovizKurCevrimi(
						String __alacakKalemi4_dovizKurCevrimi) {
					this.__alacakKalemi4_dovizKurCevrimi = __alacakKalemi4_dovizKurCevrimi;
				}
				public String get__alacakKalemi4_akdiFaiz() {
					return __alacakKalemi4_akdiFaiz;
				}
				public void set__alacakKalemi4_akdiFaiz(String __alacakKalemi4_akdiFaiz) {
					this.__alacakKalemi4_akdiFaiz = __alacakKalemi4_akdiFaiz;
				}
				public String get__alacakKalemi4_alacakKalemKodAciklama() {
					return __alacakKalemi4_alacakKalemKodAciklama;
				}
				public void set__alacakKalemi4_alacakKalemKodAciklama(
						String __alacakKalemi4_alacakKalemKodAciklama) {
					this.__alacakKalemi4_alacakKalemKodAciklama = __alacakKalemi4_alacakKalemKodAciklama;
				}
				public String get__alacakKalemi4_aciklama() {
					return __alacakKalemi4_aciklama;
				}
				public void set__alacakKalemi4_aciklama(String __alacakKalemi4_aciklama) {
					this.__alacakKalemi4_aciklama = __alacakKalemi4_aciklama;
				}
				public String get__alacakKalemi4_alacakKalemKodTuru() {
					return __alacakKalemi4_alacakKalemKodTuru;
				}
				public void set__alacakKalemi4_alacakKalemKodTuru(
						String __alacakKalemi4_alacakKalemKodTuru) {
					this.__alacakKalemi4_alacakKalemKodTuru = __alacakKalemi4_alacakKalemKodTuru;
				}
				public String get__alacakKalemi5_id() {
					return __alacakKalemi5_id;
				}
				public void set__alacakKalemi5_id(String __alacakKalemi5_id) {
					this.__alacakKalemi5_id = __alacakKalemi5_id;
				}
				public String get__alacakKalemi5_alacakKalemKod() {
					return __alacakKalemi5_alacakKalemKod;
				}
				public void set__alacakKalemi5_alacakKalemKod(
						String __alacakKalemi5_alacakKalemKod) {
					this.__alacakKalemi5_alacakKalemKod = __alacakKalemi5_alacakKalemKod;
				}
				public String get__alacakKalemi5_alacakKalemAdi() {
					return __alacakKalemi5_alacakKalemAdi;
				}
				public void set__alacakKalemi5_alacakKalemAdi(
						String __alacakKalemi5_alacakKalemAdi) {
					this.__alacakKalemi5_alacakKalemAdi = __alacakKalemi5_alacakKalemAdi;
				}
				public String get__alacakKalemi5_alacakKalemTutar() {
					return __alacakKalemi5_alacakKalemTutar;
				}
				public void set__alacakKalemi5_alacakKalemTutar(
						String __alacakKalemi5_alacakKalemTutar) {
					this.__alacakKalemi5_alacakKalemTutar = __alacakKalemi5_alacakKalemTutar;
				}
				public String get__alacakKalemi5_alacakKalemIlkTutar() {
					return __alacakKalemi5_alacakKalemIlkTutar;
				}
				public void set__alacakKalemi5_alacakKalemIlkTutar(
						String __alacakKalemi5_alacakKalemIlkTutar) {
					this.__alacakKalemi5_alacakKalemIlkTutar = __alacakKalemi5_alacakKalemIlkTutar;
				}
				public String get__alacakKalemi5_alacakKalemIlkTip() {
					return __alacakKalemi5_alacakKalemIlkTip;
				}
				public void set__alacakKalemi5_alacakKalemIlkTip(
						String __alacakKalemi5_alacakKalemIlkTip) {
					this.__alacakKalemi5_alacakKalemIlkTip = __alacakKalemi5_alacakKalemIlkTip;
				}
				public String get__alacakKalemi5_tutarTur() {
					return __alacakKalemi5_tutarTur;
				}
				public void set__alacakKalemi5_tutarTur(String __alacakKalemi5_tutarTur) {
					this.__alacakKalemi5_tutarTur = __alacakKalemi5_tutarTur;
				}
				public String get__alacakKalemi5_tutarAdi() {
					return __alacakKalemi5_tutarAdi;
				}
				public void set__alacakKalemi5_tutarAdi(String __alacakKalemi5_tutarAdi) {
					this.__alacakKalemi5_tutarAdi = __alacakKalemi5_tutarAdi;
				}
				public String get__alacakKalemi5_sabitTaksitTarihi() {
					return __alacakKalemi5_sabitTaksitTarihi;
				}
				public void set__alacakKalemi5_sabitTaksitTarihi(
						String __alacakKalemi5_sabitTaksitTarihi) {
					this.__alacakKalemi5_sabitTaksitTarihi = __alacakKalemi5_sabitTaksitTarihi;
				}
				public String get__alacakKalemi5_dovizKurCevrimi() {
					return __alacakKalemi5_dovizKurCevrimi;
				}
				public void set__alacakKalemi5_dovizKurCevrimi(
						String __alacakKalemi5_dovizKurCevrimi) {
					this.__alacakKalemi5_dovizKurCevrimi = __alacakKalemi5_dovizKurCevrimi;
				}
				public String get__alacakKalemi5_akdiFaiz() {
					return __alacakKalemi5_akdiFaiz;
				}
				public void set__alacakKalemi5_akdiFaiz(String __alacakKalemi5_akdiFaiz) {
					this.__alacakKalemi5_akdiFaiz = __alacakKalemi5_akdiFaiz;
				}
				public String get__alacakKalemi5_alacakKalemKodAciklama() {
					return __alacakKalemi5_alacakKalemKodAciklama;
				}
				public void set__alacakKalemi5_alacakKalemKodAciklama(
						String __alacakKalemi5_alacakKalemKodAciklama) {
					this.__alacakKalemi5_alacakKalemKodAciklama = __alacakKalemi5_alacakKalemKodAciklama;
				}
				public String get__alacakKalemi5_aciklama() {
					return __alacakKalemi5_aciklama;
				}
				public void set__alacakKalemi5_aciklama(String __alacakKalemi5_aciklama) {
					this.__alacakKalemi5_aciklama = __alacakKalemi5_aciklama;
				}
				public String get__alacakKalemi5_alacakKalemKodTuru() {
					return __alacakKalemi5_alacakKalemKodTuru;
				}
				public void set__alacakKalemi5_alacakKalemKodTuru(
						String __alacakKalemi5_alacakKalemKodTuru) {
					this.__alacakKalemi5_alacakKalemKodTuru = __alacakKalemi5_alacakKalemKodTuru;
				}
				
				
				
}
