package pelops.model;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "TNM_VIZIT_STATUSU")
public class VizitStatusu extends BaseEntity {
	private String adi;

}
