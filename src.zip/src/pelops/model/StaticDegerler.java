package pelops.model;

public class StaticDegerler {
	
	private int  icraDosyaID;
	private int  borcluId;
	private String icraDosyaNo;
	private String muvekkilAdi;
	private String  borcluAdi;
	
    public int getIcraDosyaID() {
		return icraDosyaID;
	}


	public void setIcraDosyaID(int icraDosyaID) {
		this.icraDosyaID = icraDosyaID;
	}


	public int getBorcluId() {
		return borcluId;
	}


	public void setBorcluId(int borcluId) {
		this.borcluId = borcluId;
	}


	public String getIcraDosyaNo() {
		return icraDosyaNo;
	}


	public void setIcraDosyaNo(String icraDosyaNo) {
		this.icraDosyaNo = icraDosyaNo;
	}


	public String getMuvekkilAdi() {
		return muvekkilAdi;
	}


	public void setMuvekkilAdi(String muvekkilAdi) {
		this.muvekkilAdi = muvekkilAdi;
	}


	public String getBorcluAdi() {
		return borcluAdi;
	}


	public void setBorcluAdi(String borcluAdi) {
		this.borcluAdi = borcluAdi;
	}


	
	

}
