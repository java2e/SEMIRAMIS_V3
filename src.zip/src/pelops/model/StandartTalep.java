package pelops.model;

public class StandartTalep {

	private int id;
	private String adi;
	private String standartText;
	private String bankaIsmi;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getAdi() {
		return adi;
	}

	public void setAdi(String adi) {
		this.adi = adi;
	}

	public String getStandartText() {
		return standartText;
	}

	public void setStandartText(String standartText) {
		this.standartText = standartText;
	}

	public String getBankaIsmi() {
		return bankaIsmi;
	}

	public void setBankaIsmi(String bankaIsmi) {
		this.bankaIsmi = bankaIsmi;
	}

}
