package pelops.model;

public class DortluYapi {

	private String sgk_standart_text;
	private String tapu_standart_text;
	private String posta_standart_text;
	private String egm_standart_text;

	// Setter Getter

	public String getSgk_standart_text() {
		return sgk_standart_text;
	}

	public void setSgk_standart_text(String sgk_standart_text) {
		this.sgk_standart_text = sgk_standart_text;
	}

	public String getTapu_standart_text() {
		return tapu_standart_text;
	}

	public void setTapu_standart_text(String tapu_standart_text) {
		this.tapu_standart_text = tapu_standart_text;
	}

	public String getPosta_standart_text() {
		return posta_standart_text;
	}

	public void setPosta_standart_text(String posta_standart_text) {
		this.posta_standart_text = posta_standart_text;
	}

	public String getEgm_standart_text() {
		return egm_standart_text;
	}

	public void setEgm_standart_text(String egm_standart_text) {
		this.egm_standart_text = egm_standart_text;
	}

}
