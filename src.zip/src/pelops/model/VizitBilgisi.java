package pelops.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import semiramis.operasyon.model.BorcluBilgisi;

@Entity
@Table(name = "TNM_VIZIT_BILGISI")
public class VizitBilgisi extends BaseEntity {

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "BORCLU_BILGISI_ID")
	private BorcluBilgisi borcluBilgisi;

	@Column(name = "VIZIT_TARIGI")
	private Date vizitTarihi;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "VIZIT_STATUSU_ID")
	private VizitStatusu vizitStatusu;

	@Column(name = "ODEME_SOZU_TARIHI")
	private Date odemeSozuTarihi;

	@Column(name = "ODEME_MIKTARI")
	private double odemeMiktari;

	@Column(name = "VIZIT_NOTU")
	private String vizitNotu;

	@Column(name = "VIZIT_PERSONEL_ID")
	private int vizitPersoneliId;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ICRA_DOSYASI_ID")
	private IcraDosyasi icraDosyasi;

	@Column(name = "USER_NAME")
	private String userName;

}
