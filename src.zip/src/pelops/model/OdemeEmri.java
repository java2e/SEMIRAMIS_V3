package pelops.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import semiramis.operasyon.model.BorcluBilgisi;

@Entity
@Table(name="TNM_ODEME_EMRI")
public class OdemeEmri {

	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="BORCLU_BILGISI_ID")
	private BorcluBilgisi borcluBilgisi; // combobox
	
	@Column(name="ODEME_TARIHI")
	private Date odemeTarihi;
	
	@Column(name="ODEME_MIKTARI")
	private double odemeMiktari;
	
	@Column(name="ODEME_SONUCU")
	private String odemeSonucu;
	
	@Column(name="ACIKLAMA")
	private String aciklama;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="ICRA_DOSYASI_ID")
	private IcraDosyasi icraDosyasi;

}
