package pelops.model;

public class UyapTakipTuru {

	public UyapTakipTuru() {

	}

	public int id;
	public String Kod;
	public String Aciklama;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getKod() {
		return Kod;
	}

	public void setKod(String kod) {
		Kod = kod;
	}

	public String getAciklama() {
		return Aciklama;
	}

	public void setAciklama(String aciklama) {
		Aciklama = aciklama;
	}

}
