package pelops.model;


public class EgmSorgu {
private	int id;
private	String aracTipi;
private	String aracPlaka;
private String aracModel;
private String aracMarka;
public String getAracModel() {
	return aracModel;
}
public void setAracModel(String aracModel) {
	this.aracModel = aracModel;
}
public String getAracMarka() {
	return aracMarka;
}
public void setAracMarka(String aracMarka) {
	this.aracMarka = aracMarka;
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getAracTipi() {
	return aracTipi;
}
public void setAracTipi(String aracTipi) {
	this.aracTipi = aracTipi;
}
public String getAracPlaka() {
	return aracPlaka;
}
public void setAracPlaka(String aracPlaka) {
	this.aracPlaka = aracPlaka;
}

}
