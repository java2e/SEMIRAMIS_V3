package pelops.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="TNM_MAL_TIPI")
public class MalTipi extends BaseEntity{
	
	@Column(name="ADI")
	private int adi;
	
}
