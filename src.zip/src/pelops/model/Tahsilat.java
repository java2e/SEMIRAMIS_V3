package pelops.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import semiramis.operasyon.model.BorcluBilgisi;

@Entity
@Table(name = "TNM_TAHSILAT")
public class Tahsilat extends BaseEntity {

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ICRA_DOSYASI_ID")
	private IcraDosyasi icraDosyasi;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ALACAKLI_BILGISI_ID")
	private AlacakliBilgisi alacakliBilgisi;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="BORCLU_BILGISI_ID")
	private BorcluBilgisi borcluBilgisi;

	@Column(name="GELIS_TARIHI")
	private Date gelisTarihi;
	@Column(name="BORC_TIPI")
	private String borcTipi;
	
	@Column(name="DOSYA_TIPI")
	private String dosyaTipi;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="ICRA_MUDURLUGU_ID")
	private IcraMudurlugu icraMudurlugu;
	
	@Column(name="TAHSILAT_TARIHI")
	private Date tahsilaTarihi;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="TAHSILAT_TIPI_ID")
	private TahsilatTipi tahsilatTipi;
	
	@Column(name="TAHSILAT_MIKTARI")
	private double tahsilatMiktari;
	
	@Column(name="TAHSILAT_STATUSU")
	private String tahsilatStatusu;
	
	@Column(name="TAHSILAT_MIKTARI_TL")
	private String tahsilatMiktariTl;

	

}
