package pelops.model;

public class Baglanti {

	int id, icradosyasiID, alacakliID, borcluID, hesaplamaID;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getIcradosyasiID() {
		return icradosyasiID;
	}

	public void setIcradosyasiID(int icradosyasiID) {
		this.icradosyasiID = icradosyasiID;
	}

	public int getAlacakliID() {
		return alacakliID;
	}

	public void setAlacakliID(int alacakliID) {
		this.alacakliID = alacakliID;
	}

	public int getBorcluID() {
		return borcluID;
	}

	public void setBorcluID(int borcluID) {
		this.borcluID = borcluID;
	}

	public int getHesaplamaID() {
		return hesaplamaID;
	}

	public void setHesaplamaID(int hesaplamaID) {
		this.hesaplamaID = hesaplamaID;
	} 
}
