package pelops.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="TNM_POSTA")
public class Posta extends BaseEntity{

	@Column(name="SERIAL")
	private int serial;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="ICRA_DOSYASI_ID")
	private IcraDosyasi icraDosyasi;
	
	@Column(name="BARKOD")
	private String barkod;
	
	@Column(name="DURUM")
	private int durum;

}
