package pelops.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="TNM_HACZEDILEN_TIPI")
public class HaczedilenTipi {
	
	@Column(name="ADI")
	private String adi;

}
