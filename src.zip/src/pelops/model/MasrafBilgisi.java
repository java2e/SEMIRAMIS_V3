package pelops.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import semiramis.operasyon.model.BorcluBilgisi;

@Entity
@Table(name="TNM_MASRAF_BILGISI")
public class MasrafBilgisi extends BaseEntity{


	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="ICRA_DOSYASI_ID")
	private IcraDosyasi icraDosyasi;
	
	@Column(name="MUVEKKIL_ADI")
	private String muvekkilAdi;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="BORCLU_ID")
	private BorcluBilgisi borcluBilgisi;
	
	@Column(name="MASRAF_TARIHI")
	private Date masrafTarihi;
	
	@Column(name="MASRAF_MIKTARI")
	private Double masrafMiktari;
	
	@Column(name="MASRAF_ACIKLAMA")
	private String masrafAciklama;
	
	@Column(name="MASRAF_PERSONEL_ID")
	private int masrafPersonel_adi_id;
	
	@Column(name="MASRAF_UYGULAMA_ASAMASI_ID")
	private int masrafUygulamaAsamasiId;

	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="MASRAF_TIPI_ID")
	private MasrafTipi masrafTipi;
	
	@Column(name="MASRAF_UYGULAMA_ASAMASI")
	private String masrafUygulamaAsamasiName;
	
	
}
