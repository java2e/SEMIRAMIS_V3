package pelops.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="TNM_ITIRAZ_TIPI")
public class ItirazTipi extends BaseEntity{
	
	@Column(name="ADI")
	private String adi;	
}
