package pelops.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="TNM_TAHSILAT_TIPI")
public class TahsilatTipi extends BaseEntity{

	@Column(name="ADI")
	private String adi;
}
