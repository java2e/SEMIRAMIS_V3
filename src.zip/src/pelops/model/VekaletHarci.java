package pelops.model;

public class VekaletHarci {

	private int id;
	private int yil;
	private double tutar;
	private String konusu;

	public int getYil() {
		return yil;
	}

	public void setYil(int yil) {
		this.yil = yil;
	}

	public double getTutar() {
		return tutar;
	}

	public void setTutar(double tutar) {
		this.tutar = tutar;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getKonusu() {
		return konusu;
	}

	public void setKonusu(String konusu) {
		this.konusu = konusu;
	}
	
	

}
