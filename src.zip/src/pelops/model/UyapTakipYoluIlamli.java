package pelops.model;

public class UyapTakipYoluIlamli {

	private int id;
	private String Kod;
	private String Aciklama;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getKod() {
		return Kod;
	}

	public void setKod(String kod) {
		Kod = kod;
	}

	public String getAciklama() {
		return Aciklama;
	}

	public void setAciklama(String aciklama) {
		Aciklama = aciklama;
	}

}
