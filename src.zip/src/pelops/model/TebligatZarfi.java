package pelops.model;

public class TebligatZarfi {

	
	private String icraDosyaNo;
	private String icraMudurluguAdi;
	private String borcluAdi;
	private String borcluAdres;
	private String muzekkereTalepAdi;
	private String alacakliAdi;
	private String avukatAdi;
	private Object barkod;
	
	private String muameleTarihiTxt;
	
	
	
	
	
	public String getMuameleTarihiTxt() {
		return muameleTarihiTxt;
	}
	public void setMuameleTarihiTxt(String muameleTarihiTxt) {
		this.muameleTarihiTxt = muameleTarihiTxt;
	}
	public String getIcraDosyaNo() {
		return icraDosyaNo;
	}
	public void setIcraDosyaNo(String icraDosyaNo) {
		this.icraDosyaNo = icraDosyaNo;
	}

	public String getIcraMudurluguAdi() {
		return icraMudurluguAdi;
	}
	public void setIcraMudurluguAdi(String icraMudurluguAdi) {
		this.icraMudurluguAdi = icraMudurluguAdi;
	}
	public String getBorcluAdi() {
		return borcluAdi;
	}
	public void setBorcluAdi(String borcluAdi) {
		this.borcluAdi = borcluAdi;
	}
	public String getBorcluAdres() {
		return borcluAdres;
	}
	public void setBorcluAdres(String borcluAdres) {
		this.borcluAdres = borcluAdres;
	}
	
	

	public String getMuzekkereTalepAdi() {
		return muzekkereTalepAdi;
	}
	public void setMuzekkereTalepAdi(String muzekkereTalepAdi) {
		this.muzekkereTalepAdi = muzekkereTalepAdi;
	}
	public String getAlacakliAdi() {
		return alacakliAdi;
	}
	public void setAlacakliAdi(String alacakliAdi) {
		this.alacakliAdi = alacakliAdi;
	}
	public String getAvukatAdi() {
		return avukatAdi;
	}
	public void setAvukatAdi(String avukatAdi) {
		this.avukatAdi = avukatAdi;
	}
	public Object getBarkod() {
		return barkod;
	}
	public void setBarkod(Object barkod) {
		this.barkod = barkod;
	}
	
	
	
	

}
