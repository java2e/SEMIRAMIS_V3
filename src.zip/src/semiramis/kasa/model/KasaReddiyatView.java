package semiramis.kasa.model;

public class KasaReddiyatView 
{
	
	private String tarih;
	
	private String personelAdSoyad;
	
	private float miktar;

	public String getTarih() {
		return tarih;
	}

	public void setTarih(String tarih) {
		this.tarih = tarih;
	}

	public String getPersonelAdSoyad() {
		return personelAdSoyad;
	}

	public void setPersonelAdSoyad(String personelAdSoyad) {
		this.personelAdSoyad = personelAdSoyad;
	}

	public float getMiktar() {
		return miktar;
	}

	public void setMiktar(float miktar) {
		this.miktar = miktar;
	}
	
	
	

}
