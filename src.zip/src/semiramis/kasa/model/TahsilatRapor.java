package semiramis.kasa.model;

public class TahsilatRapor 
{
	
	private double toplam;
	
	private String muvekkilAdi;
	
	private int muvekkilId;

	public double getToplam() {
		return toplam;
	}

	public void setToplam(double toplam) {
		this.toplam = toplam;
	}

	public String getMuvekkilAdi() {
		return muvekkilAdi;
	}

	public void setMuvekkilAdi(String muvekkilAdi) {
		this.muvekkilAdi = muvekkilAdi;
	}

	public int getMuvekkilId() {
		return muvekkilId;
	}

	public void setMuvekkilId(int muvekkilId) {
		this.muvekkilId = muvekkilId;
	}
	
	

}
