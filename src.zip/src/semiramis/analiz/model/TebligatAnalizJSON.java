package semiramis.analiz.model;

public class TebligatAnalizJSON 
{
	
	private int toplam;
	
	private int id;
	
	private String adi;

	public int getToplam() {
		return toplam;
	}

	public void setToplam(int toplam) {
		this.toplam = toplam;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getAdi() {
		return adi;
	}

	public void setAdi(String adi) {
		this.adi = adi;
	}
	
	
	

}
