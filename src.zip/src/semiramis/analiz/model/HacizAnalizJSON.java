package semiramis.analiz.model;

public class HacizAnalizJSON {
	
	private int hacizStatusuId;
	
	private String hacizStatusuAdi;
	
	private int hacizTuruId;
	
	private String hacizTuruAdi;
	
	private int toplam;

	public int getHacizStatusuId() {
		return hacizStatusuId;
	}

	public void setHacizStatusuId(int hacizStatusuId) {
		this.hacizStatusuId = hacizStatusuId;
	}

	public String getHacizStatusuAdi() {
		return hacizStatusuAdi;
	}

	public void setHacizStatusuAdi(String hacizStatusuAdi) {
		this.hacizStatusuAdi = hacizStatusuAdi;
	}

	public int getHacizTuruId() {
		return hacizTuruId;
	}

	public void setHacizTuruId(int hacizTuruId) {
		this.hacizTuruId = hacizTuruId;
	}

	public String getHacizTuruAdi() {
		return hacizTuruAdi;
	}

	public void setHacizTuruAdi(String hacizTuruAdi) {
		this.hacizTuruAdi = hacizTuruAdi;
	}

	public int getToplam() {
		return toplam;
	}

	public void setToplam(int toplam) {
		this.toplam = toplam;
	}
	
	

}
