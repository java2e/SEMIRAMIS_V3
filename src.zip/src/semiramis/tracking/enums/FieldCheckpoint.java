package semiramis.tracking.enums;

/**
 * Created by User on 26/6/14.
 */
public enum FieldCheckpoint {

    created_at,
    checkpoint_time,
    city,
    coordinates,
    country_iso3,
    country_name,
    message,
    state,
    tag,
    zip;
}
