package semiramis.tracking.enums;

/**
 * Created by User on 13/6/14.
 */
public enum StatusTag {
    Pending,InTransit,OutForDelivery,AttemptFail,Delivered,Exception,Expired,InfoReceived
}
