package semiramis.tracking.classes;

/**
 * Created by User on 10/6/14.
 */
public class AftershipAPIException extends Exception{

    public AftershipAPIException() {}

    public AftershipAPIException(String message)
    {
        super(message);
    }

}
