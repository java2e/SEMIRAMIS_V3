package semiramis.tracking.classes.query;


import java.util.List;

import semiramis.tracking.classes.Tracking;

/**
 * Created by georgestoica on 30/3/16.
 */
public interface TrackingResponse {
    List<Tracking> getTrackingData();
}
