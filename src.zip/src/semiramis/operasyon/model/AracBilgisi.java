package semiramis.operasyon.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import pelops.model.AracTipi;
import pelops.model.BaseEntity;

@Entity
@Table(name="TNM_ARAC_BILGISI")
public class AracBilgisi extends BaseEntity{
	
	@Column(name="ARAC_PLAKA_NO")
	private String aracPlakaNo;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="ARAC_TIPI_ID")
	private AracTipi aracTipi;
	
	@Column(name="ARAC_RENK")
	private String aracRenk;
	
	@Column(name="ARAC_DEGERI")
	private String aracDegeri;
	
	@Column(name="ARAC_MARKASI")
	private String aracMarkasi;
	
	@Column(name="ARAC_MODELI")
	private String aracModeli;

}
