package semiramis.operasyon.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import pelops.model.BaseEntity;

@Entity
@Table(name="TNM_TAPU_MUDURLUGU")
public class TapuMudurlugu extends BaseEntity {

	@Column(name="ADI")
	private String adi;
	
}
