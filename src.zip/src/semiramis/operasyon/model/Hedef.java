package semiramis.operasyon.model;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import pelops.model.AlacakliBilgisi;
import pelops.model.BaseEntity;
import pelops.model.User;

@Table(name="TNM_HEDEF")
@Entity
public class Hedef extends BaseEntity{

	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="USER_ID")
	private User user;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="ALACAKLI_BILGISI_ID")
	private AlacakliBilgisi alacakliBilgisi;
	
	@Column(name="GUNLUK_HEDEF")
	private double gunlukHedef;
	
	@Column(name="AYLIK_HEDEF")
	private double aylikHedef;

	@Column(name="ILGILI_AY")
	private int ilgiliAy;

	@Column(name="ILGILI_YIL")
	private int ilgili_yil;

	@Column(name="EKLEME_TARIHI")
	private Date eklemeTarihi;
	
	@Column(name="GUNCELLEME_TARIHI")
	private Date guncelleme_tarihi;

	@Column(name="YAZDIRMA_TARIH")
	private String yazdirmaTarih;
	
}
