package semiramis.operasyon.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import pelops.model.AlacakliBilgisi;
import pelops.model.BaseEntity;
import pelops.model.HacizTipi;
import pelops.model.HaczedilenTipi;
import pelops.model.IcraDosyasi;
import pelops.model.IcraMudurlugu;
import pelops.model.User;

@Entity
@Table(name = "TNM_HACIZ_BILGISI")
public class HacizBilgisi extends BaseEntity {

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "BORCLU_ID")
	private BorcluBilgisi borcluBilgisi;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "PERSONEL_ID")
	private User user;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "HACIZ_TIPI_ID")
	private HacizTipi hacizTipi;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "HACIZ_STATUSU_ID")
	private HacizStatusu hacizStatusu;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "TALIMAT_ICRA_MUDURLUGU_ID")
	private IcraMudurlugu talimatIcraMd;

	@Column(name = "DOSYA_NO")
	private String dosyaNo;

	@Column(name = "TALİMAT_TARIHI")
	private String talimatTarihi;

	@Column(name = "HACIZ_TARIHI")
	private Date hacizTarihi;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "HACZEDILEN_TIPI_ID")
	private HaczedilenTipi haczedilenTipi;

	@Column(name = "HACIZ_BEDELI")
	private double hacizBedeli;

	@Column(name = "TESLIM_YERI_ID")
	private int teslimYeriId;
	@Column(name = "TESLIM_YERI")
	private String teslimYeri;
	@Column(name = "SEHIR")
	private String sehir;
	@Column(name = "ACIKLAMA")
	private String aciklama;
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ICRA_DOSYASI_ID")
	private IcraDosyasi icraDosyasi;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "HACIZ_SONUCU_ID")
	private HacizSonucu hacizSonucu;
	@Column(name = "YAZDIRMA_TARIHI")
	private String yazdirmaTarih;
	@Column(name = "HACIZ_BEDELI_TL")
	private String hacizBedeliTL;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ALACAKLI_BILGISI_ID")
	private AlacakliBilgisi alacakliBilgisi;


}
