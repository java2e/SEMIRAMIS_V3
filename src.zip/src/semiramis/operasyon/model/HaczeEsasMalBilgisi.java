package semiramis.operasyon.model;

import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import pelops.model.Adres;
import pelops.model.BaseEntity;
import pelops.model.IcraDosyasi;

public class HaczeEsasMalBilgisi extends BaseEntity {

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "BORCLU_BILGISI_ID")
	private BorcluBilgisi borcluBilgisi;

	@OneToMany(fetch = FetchType.LAZY)
	private List<TapuBilgisi> tapuBilgisi;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ICRA_DOSYASI_ID")
	private IcraDosyasi icraDosyasi;

	@Column(name="MULK_TIPI")
	private int mulkTipiId;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ARAC_BILGISI_ID")
	private AracBilgisi aracBilgisi;

	@Column(name = "BANKA_HESAP_NO")
	private String bankaHesapNo;
	@Column(name = "MUHATAP_ADI")
	private String muhatapAdi;
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "MUHATAP_ADRES_ID")
	private Adres muhatapAdresi;

	@Column(name = "MAL_TUTARI")
	private int malTutari;

	@Column(name = "MAL_TIPI_ID")
	private int malTipiId;
	@Column(name = "MAL_TIPI")
	private String malTipi;
	@Column(name = "MEVDUAT_BILGISI")
	private String mevduatBilgisi;
	@Column(name = "EKLEME_TARIHI")
	private Date eklemeTarihi;
	@Column(name = "GUNCELLEME_TARIHI")
	private Date guncellemeTarihi;

}
