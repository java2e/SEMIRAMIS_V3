package semiramis.operasyon.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import pelops.model.BaseEntity;
import pelops.model.IcraDosyasi;
import pelops.model.IcraMudurlugu;
import semiramis.tracking.classes.Checkpoint;
import semiramis.tracking.classes.Tracking;

@Table(name = "TNM_TEBLIGAT")
public class Tebligat extends BaseEntity {

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ICRA_DOSYASI_ID")
	private IcraDosyasi icraDosyasi;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "BORCLU_BILGISI_ID")
	private BorcluBilgisi borcluBilgisi;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "TEBLIGAT_TURU_ID")
	private TebligatTuru tebligatTuru;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "TEBLIGAT_STATUSU_ID")
	private TebligatStatusu tebligatStatusu;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "TEBLIGAT_SONUCU_ID")
	private TebligatSonucu tebligatSonucu;

	@Column(name = "TEBLIGAT_TARIHI")
	private Date tebligatTarihi;

	@Column(name = "BARKOD")
	private String barkod;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ICRA_MUDURLUGU_ID")
	private IcraMudurlugu icraMudurlugu;

	// private Tracking tracking;

	// private Checkpoint lastCheckPoint;

}
