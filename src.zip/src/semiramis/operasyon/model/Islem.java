package semiramis.operasyon.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import pelops.model.BaseEntity;
import pelops.model.IcraDosyasi;

@Table(name="TNM_ISLEM")
@Entity
public class Islem extends BaseEntity {

	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="ICRA_DOSYASI_ID")
	private IcraDosyasi icraDosyasi;
	
	@Column(name="ISLEM_ID")
	private int islem_id;
	
	@Column(name="BARKOD")
	private String barkod;
	
	@Column(name="BARKOD_ENCODED")
	private String barcodEncoded;
	
	@Column(name="ISLEM_ADI")
	private String islemAdi;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="TEBLIGAT_ID")
	private Tebligat tebligat;
	
	@Column(name="SONUC")
	private String sonuc;
	
	@Column(name="STATUSU")
	private String statusu;

	
}
