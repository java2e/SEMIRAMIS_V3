package semiramis.operasyon.model;

public class SubReport 
{
	
	private String kayit;

	public String getKayit() {
		return kayit;
	}

	public void setKayit(String kayit) {
		this.kayit = kayit;
	}
	

}
