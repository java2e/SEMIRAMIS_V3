package semiramis.operasyon.model;

public class PairLevha {
	
	private int adet;
	
	private int durum;
	
	private String durumTxt;
	
	
	

	public String getDurumTxt() {
		return durumTxt;
	}

	public void setDurumTxt(String durumTxt) {
		this.durumTxt = durumTxt;
	}

	public int getAdet() {
		return adet;
	}

	public void setAdet(int adet) {
		this.adet = adet;
	}

	public int getDurum() {
		return durum;
	}

	public void setDurum(int durum) {
		this.durum = durum;
	}
	
	

}
