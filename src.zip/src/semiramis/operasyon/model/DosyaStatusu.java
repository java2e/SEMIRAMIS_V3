package semiramis.operasyon.model;

public class DosyaStatusu 
{
	
	public static final String DERDEST_RENK="#1a53ff";
	public static final String HITAM_RENK="#ff0000";
	public static final String TEMLIK_RENK="#009933";
	public static final String VEFAT_RENK="black";
	public static final String ITIRAZ_RENK="#ffcc00";
	
	public static final String IZLEME_RENK="red";

	
	public static final int DERDEST_ID=6;
	public static final int HITAM_ID=7;
	public static final int TEMLIK_ID=9;
	public static final int VEFAT_ID=10;
	public static final int ITIRAZ_ID=11;
	

}
