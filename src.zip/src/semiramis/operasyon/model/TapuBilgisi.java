package semiramis.operasyon.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import pelops.model.BaseEntity;
import pelops.model.Il;
import pelops.model.Ilce;

@Entity
@Table(name = "TNM_TAPU_BILGISI")
public class TapuBilgisi extends BaseEntity {
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "IL_ID")
	private Il il;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ILCE_ID")
	private Ilce ilce;

	@Column(name = "ACIKLAMA")
	private String aciklama;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "TAPU_MUDURLUGU_ID")
	private TapuMudurlugu tapuMudurlugu;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "HACZE_ESAS_MAL_BILGISI_ID")
	private HaczeEsasMalBilgisi haczeEsasMalBilgisi;

	@Column(name = "TAPU_MULK_TIPI")
	private String tapuMulkTipi;

	@Column(name = "TAPU_PARSEL")
	private String tapuParsel;

	@Column(name = "TAPU_ADA")
	private String tapuAda;

	@Column(name = "TAPU_SAYFA_NO")
	private String tapuSayfaNo;

	@Column(name = "TAPU_CILT_NO")
	private String tapuCiltNo;

	@Column(name = "TAPU_SICIL_MUDURLUK")
	private String tapuSicilMudurluk;

}
