package semiramis.operasyon.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import pelops.model.AlacakliBilgisi;
import pelops.model.BaseEntity;
import pelops.model.IcraDosyasi;
import pelops.model.User;


@Entity
@Table(name="TNM_IZLEME_BILGISI")
public class IzlemeBilgisi extends BaseEntity{

	@Column(name="IZLEME_TARIHI")
	private Date izlemeTarihi;
	
	@Column(name="IZLEME_TARIHI")
	private Date izlemeSonucuTarihi;
	
	@Column(name="ODEME_SOZU_TARIHI")
	private Date odemeSozuTarihi;
	@Column(name="ODEME_SOZU_MIKTARI")
	private Double odemeSozuMiktari;
	
	@Column(name="ACIKLAMA")
	private String aciklama;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="PERSONEL_ID")
	private User personel;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="ICRA_DOSYASI_ID")
	private IcraDosyasi icraDosyasi;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="IZLEME_SONUCU_ID")
	private IzlemeSonucu izlemeSonucu;
	
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="IZLEME_STATUSU_ID")
	private IzlemeStatusu izlemeStatusu;
	
	@Column(name="VIZIT_DURUMU")
	private boolean vizitDurumu;
	
	@Column(name="CAGRI_ADET")
	private int cagriAdet;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="ALACAKLI_BILGISI_ID")
	private AlacakliBilgisi alacakliBilgisi;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="BORCLU_BILGISI_ID")
	private BorcluBilgisi borcluBilgisi;
	


}
