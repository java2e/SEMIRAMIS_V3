package semiramis.operasyon.model;

public class Levha {

	private int aracSayisi;
	private int evSayisi;
	private int evDurum;
	private String evDurumTxt;
	private int aracDurum;
	private String aracDurumTxt;
	
	private int maasSayisi;
	private int maasDurum;
	private String maasDurumTxt;
	
	
	private int vizitSayisi;
	private int vizitDurum;
	private String vizitDurumTxt;
	
	private String tebligatDurumTxt;
	private String tebligatTarihTxt;
	
	private String tebligatSonucuTxt;
	private String tebligatTuruTxt;
	
	
	
	
	
	
	
	
	
	

	public String getTebligatSonucuTxt() {
		return tebligatSonucuTxt;
	}

	public void setTebligatSonucuTxt(String tebligatSonucuTxt) {
		this.tebligatSonucuTxt = tebligatSonucuTxt;
	}

	public String getTebligatTuruTxt() {
		return tebligatTuruTxt;
	}

	public void setTebligatTuruTxt(String tebligatTuruTxt) {
		this.tebligatTuruTxt = tebligatTuruTxt;
	}

	public String getTebligatTarihTxt() {
		return tebligatTarihTxt;
	}

	public void setTebligatTarihTxt(String tebligatTarihTxt) {
		this.tebligatTarihTxt = tebligatTarihTxt;
	}

	public String getTebligatDurumTxt() {
		return tebligatDurumTxt;
	}

	public void setTebligatDurumTxt(String tebligatDurumTxt) {
		this.tebligatDurumTxt = tebligatDurumTxt;
	}

	public int getAracSayisi() {
		return aracSayisi;
	}

	public void setAracSayisi(int aracSayisi) {
		this.aracSayisi = aracSayisi;
	}

	public int getEvSayisi() {
		return evSayisi;
	}

	public void setEvSayisi(int evSayisi) {
		this.evSayisi = evSayisi;
	}

	public int getEvDurum() {
		return evDurum;
	}

	public void setEvDurum(int evDurum) {
		this.evDurum = evDurum;
	}

	public String getEvDurumTxt() {
		return evDurumTxt;
	}

	public void setEvDurumTxt(String evDurumTxt) {
		this.evDurumTxt = evDurumTxt;
	}

	public int getAracDurum() {
		return aracDurum;
	}

	public void setAracDurum(int aracDurum) {
		this.aracDurum = aracDurum;
	}

	public String getAracDurumTxt() {
		return aracDurumTxt;
	}

	public void setAracDurumTxt(String aracDurumTxt) {
		this.aracDurumTxt = aracDurumTxt;
	}

	public int getMaasSayisi() {
		return maasSayisi;
	}

	public void setMaasSayisi(int maasSayisi) {
		this.maasSayisi = maasSayisi;
	}

	public int getMaasDurum() {
		return maasDurum;
	}

	public void setMaasDurum(int maasDurum) {
		this.maasDurum = maasDurum;
	}

	public String getMaasDurumTxt() {
		return maasDurumTxt;
	}

	public void setMaasDurumTxt(String maasDurumTxt) {
		this.maasDurumTxt = maasDurumTxt;
	}

	public int getVizitSayisi() {
		return vizitSayisi;
	}

	public void setVizitSayisi(int vizitSayisi) {
		this.vizitSayisi = vizitSayisi;
	}

	public int getVizitDurum() {
		return vizitDurum;
	}

	public void setVizitDurum(int vizitDurum) {
		this.vizitDurum = vizitDurum;
	}

	public String getVizitDurumTxt() {
		return vizitDurumTxt;
	}

	public void setVizitDurumTxt(String vizitDurumTxt) {
		this.vizitDurumTxt = vizitDurumTxt;
	}
	
	
	
	
	

}
