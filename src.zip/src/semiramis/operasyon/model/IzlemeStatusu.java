package semiramis.operasyon.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import pelops.model.BaseEntity;

@Table(name="TNM_IZLEME_STATUSU")
@Entity
public class IzlemeStatusu extends BaseEntity{

	@Column(name="ADI")
	private String adi;
	
}
