package semiramis.operasyon.model;

import java.sql.Date;
import java.sql.Time;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import pelops.model.Adres;
import pelops.model.BaseEntity;
import pelops.model.Il;
import pelops.model.Ilce;

@Entity
@Table(name = "TNM_BORCLU_BİLGİSİ")
public class BorcluBilgisi extends BaseEntity {

	@Column(name = "TC_NO")
	private String tcNo;

	@Column(name = "URUN_NO")
	private String urunNo;
	@Column(name = "AD_SOYAD")
	private String adSoyad;
	@Column(name = "BORCLU_TIPI_ID")
	private int borcluTipiId;
	@Column(name = "TICARI_SICIL_NO")
	private int ticariSicilNo;
	@Column(name = "VERGI_NO")
	private int vergiNo;
	@Column(name = "VERGI_DAIRESI_ID")
	private int vergiDairesiId;
	@Column(name = "SSK_ISYERI_NO")
	private int sskIsyeriNo;
	@Column(name = "SERVIS_NO")
	private int servisNo;
	@Column(name = "MUSTERI_NO")
	private String musteriNo;
	@Column(name = "TALIMAT_ICRA_MUDURLUGU_ID")
	private int talimatIcraMudId;
	@Column(name = "EMAIL")
	private String email;
	@Column(name = "WEB_ADRES")
	private String webAdres;

	@Column(name = "ADRES_TURU_ID")
	private int adresTuruId;

	@Column(name = "NOT")
	private String note;
	@Column(name = "TELEFON")
	private int telefonNo;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ADRES_ID")
	private Adres adres;

	@Column(name = "ISTIHBARI_NOTLAR")
	private String istihbariNotlar;

	@Column(name = "TELEFON_NO2")
	private String telefonNo2;
	@Column(name = "TELEFON_NO1")
	private String telefonnNo1;

	@Column(name = "ISYERI_ADI")
	private String isYeriAdi;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ISYERI_ADRES_ID")
	private Adres isyeriAdres;

	@Column(name = "DEPARTMAN")
	private String departman;
	@Column(name = "IS_UNVANI")
	private String isUnvani;
	@Column(name = "CINSIYET")
	private String cinsiyet;
	@Column(name = "BABA_ADI")
	private String babaAdi;
	@Column(name = "ANA_ADI")
	private String anaAdi;
	@Column(name = "DOGUM_YERI")
	private String dogumYeri;
	@Column(name = "DOGUM_TARIHI")
	private Date dogumTarihi;
	@Column(name = "MEDENI_HALI")
	private String medeniHali;

	@Column(name = "MAHALLE")
	private String mahalle;

	@Column(name = "KOY")
	private String koy;

	@Column(name = "VERILIS_YERI")
	private String verilisYeri;

	@Column(name = "VERILIS_TARIHI")
	private Date verilisTarihi;

	@Column(name = "VEFAT")
	private String vefat;

	@Column(name = "RESIM")
	private String resim;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "IL_ID")
	private Il il;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ILCE_ID")
	private Ilce ilce;

	@Column(name = "CILT_NO")
	private int ciltNo;

	@Column(name = "SIRA_NO")
	private int siraNo;

	@Column(name = "VERILIS_NEDENI")
	private String verilisNedeni;

	@Column(name = "SSK_SICIL_NO")
	private String sskSicilNo;

	@Column(name = "X")
	private String X;

	@Column(name = "X")
	private String Y;

	
}
