package semiramis.uyap.model;

public class Sgk {

	private String tcNo;
	private String isYeri;
	private String isYeriAdress;
	private String isYeriSicilNo;
	private String borcluSigortaStatusu;

	public String getBorcluSigortaStatusu() {
		return borcluSigortaStatusu;
	}

	public void setBorcluSigortaStatusu(String borcluSigortaStatusu) {
		this.borcluSigortaStatusu = borcluSigortaStatusu;
	}

	public String getTcNo() {
		return tcNo;
	}

	public void setTcNo(String tcNo) {
		this.tcNo = tcNo;
	}

	public String getIsYeri() {
		return isYeri;
	}

	public void setIsYeri(String isYeri) {
		this.isYeri = isYeri;
	}

	public String getIsYeriAdress() {
		return isYeriAdress;
	}

	public void setIsYeriAdress(String isYeriAdress) {
		this.isYeriAdress = isYeriAdress;
	}

	public String getIsYeriSicilNo() {
		return isYeriSicilNo;
	}

	public void setIsYeriSicilNo(String isYeriSicilNo) {
		this.isYeriSicilNo = isYeriSicilNo;
	}

}
