package semiramis.uyap.model;

public class XMLBorcluModel 
{
	
	private String adi;
	
	private String soyadi;
	
	private String tcNo;

	private String anneAdi;
	
	private String babaAdi;
	
	private int ilId;
	
	private int ilceId;
	
	private String adres;
	
	private String adresTuru;
	
	private String telNo;
	
	private String dogumTarihi;
	
	private String dogumYeri;
	
	private String cinsiyet;
	
	private int ciltNo;
	
	private int siraNo;
	
	private int aileSiraNo;
	
	private String cuzdanSeriNo;

	public String getAdi() {
		return adi;
	}

	public void setAdi(String adi) {
		this.adi = adi;
	}

	public String getSoyadi() {
		return soyadi;
	}

	public void setSoyadi(String soyadi) {
		this.soyadi = soyadi;
	}

	public String getTcNo() {
		return tcNo;
	}

	public void setTcNo(String tcNo) {
		this.tcNo = tcNo;
	}

	public String getAnneAdi() {
		return anneAdi;
	}

	public void setAnneAdi(String anneAdi) {
		this.anneAdi = anneAdi;
	}

	public String getBabaAdi() {
		return babaAdi;
	}

	public void setBabaAdi(String babaAdi) {
		this.babaAdi = babaAdi;
	}

	public int getIlId() {
		return ilId;
	}

	public void setIlId(int ilId) {
		this.ilId = ilId;
	}

	public int getIlceId() {
		return ilceId;
	}

	public void setIlceId(int ilceId) {
		this.ilceId = ilceId;
	}

	public String getAdres() {
		return adres;
	}

	public void setAdres(String adres) {
		this.adres = adres;
	}

	public String getAdresTuru() {
		return adresTuru;
	}

	public void setAdresTuru(String adresTuru) {
		this.adresTuru = adresTuru;
	}

	public String getTelNo() {
		return telNo;
	}

	public void setTelNo(String telNo) {
		this.telNo = telNo;
	}

	public String getDogumTarihi() {
		return dogumTarihi;
	}

	public void setDogumTarihi(String dogumTarihi) {
		this.dogumTarihi = dogumTarihi;
	}

	public String getDogumYeri() {
		return dogumYeri;
	}

	public void setDogumYeri(String dogumYeri) {
		this.dogumYeri = dogumYeri;
	}

	public String getCinsiyet() {
		return cinsiyet;
	}

	public void setCinsiyet(String cinsiyet) {
		this.cinsiyet = cinsiyet;
	}

	public int getCiltNo() {
		return ciltNo;
	}

	public void setCiltNo(int ciltNo) {
		this.ciltNo = ciltNo;
	}

	public int getSiraNo() {
		return siraNo;
	}

	public void setSiraNo(int siraNo) {
		this.siraNo = siraNo;
	}

	public int getAileSiraNo() {
		return aileSiraNo;
	}

	public void setAileSiraNo(int aileSiraNo) {
		this.aileSiraNo = aileSiraNo;
	}

	public String getCuzdanSeriNo() {
		return cuzdanSeriNo;
	}

	public void setCuzdanSeriNo(String cuzdanSeriNo) {
		this.cuzdanSeriNo = cuzdanSeriNo;
	}
	
	
	
	
	
}
