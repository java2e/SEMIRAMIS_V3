package pelops.model;

public class HesaplarList {

	private int hesapId;
	private String hesapAdi;
	public int getHesapId() {
		return hesapId;
	}
	public void setHesapId(int hesapId) {
		this.hesapId = hesapId;
	}
	public String getHesapAdi() {
		return hesapAdi;
	}
	public void setHesapAdi(String hesapAdi) {
		this.hesapAdi = hesapAdi;
	}
	
	
}
