package pelops.model;

public class TakipTipi {

}
