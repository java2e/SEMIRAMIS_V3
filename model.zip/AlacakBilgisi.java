package pelops.model;

import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.apache.commons.beanutils.BeanAccessLanguageException;

@Entity
@Table(name="TNM_ALACAK_BİLGİSİ")
public class AlacakBilgisi extends BaseEntity {

	
	@OneToMany(fetch=FetchType.LAZY)
	@JoinColumn(name="ICRA_DOSYASI_ID")
	private List<IcraDosyasi> icraDosyasi;
	
	@Column(name="BELGE_TIPI_ID")
	private  int belge_tipi_id;
	
	@Column(name="BELGE_TIPI")
	private String belgeTipi;
	
	@Column(name="BELGE_STATUSU")
	private String belgeStatusu;
	
	@Column(name="DOVIZ_TIPI")
	private String dovizTipi;
	
	@Column(name="DOVIZ_KURU")
	private String dovizKuru;
	
	@Column(name="TANZIM_TARIHI")
	private Date tanzimTarihi;
	
	@Column(name="VADE_TARIHI")
	private Date vadeTarihi;
	
	@Column(name="IHTARNAME_TARIHI")
	private Date ihtarnameTarihi;
	
	@Column(name="BELGE_MIKTARI")
	private double belgeMiktari;
	
	@Column(name="ODENEN_MIKTAR")
	private double odenenMiktar;
	
	@ManyToOne(fetch=FetchType.LAZY)
	private FaizTipi faizTipi;
	
	@Column(name="ACIKLAMA")
	String aciklama;
	
	@Column(name="BELGE_MIKTARI_TL")
	String belgeMiktariTL;
	
}
