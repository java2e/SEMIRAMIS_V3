package pelops.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="TNM_HARC_BILGISI")
public class HarcBilgisi extends BaseEntity{

	@Column(name="HARC_TARIHI")
	private Date harcTarihi;
	
	@Column(name="HARC_TIPI")
	private String harcTipi;
	
	@Column(name="HARC_ORANI")
	private Float harcOrani;
	
	@Column(name="HARC_MIKTARI")
	private Float harcMiktari;
	
	@Column(name="UYGULAMA_ASAMASI")
	private String uygulamaAsamasi;
}
