package pelops.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="TNM_ILCE")
public class Ilce extends BaseEntity {

	@Column(name="ADI")
	private String adi;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="IL_ID")
	private Il il;

}
