package pelops.model;

public class VekaletSinirlari {

	
	private int id;
		private int yil;
		private int  yuzde_1 ;
	 	private double sinir_1 ;
	 	private int yuzde_2 ;
	 	private double sinir_2 ;
	 	private int yuzde_3 ;
	 	private double sinir_3 ;
	 	private int yuzde_4 ;
	 	private double sinir_4 ;
	 	private int yuzde_5 ;
	 	private double	sinir_5 ;
	 	private int yuzde_6 ;
	 	private double sinir_6 ;
	 	private int yuzde_7 ;
	 	private double sinir_7 ;
	 	private int yuzde_8 ;
	 	private double sinir_8 ;
	 	private double vekalet_ucret ;
	 	private double vekalet_ucret_sinir ;
	 	
		public int getId() {
			return id;
		}
		public void setId(int id) {
			this.id = id;
		}
		public int getYil() {
			return yil;
		}
		public void setYil(int yil) {
			this.yil = yil;
		}
		public int getYuzde_1() {
			return yuzde_1;
		}
		public void setYuzde_1(int yuzde_1) {
			this.yuzde_1 = yuzde_1;
		}
		public double getSinir_1() {
			return sinir_1;
		}
		public void setSinir_1(double sinir_1) {
			this.sinir_1 = sinir_1;
		}
		public int getYuzde_2() {
			return yuzde_2;
		}
		public void setYuzde_2(int yuzde_2) {
			this.yuzde_2 = yuzde_2;
		}
		public double getSinir_2() {
			return sinir_2;
		}
		public void setSinir_2(double sinir_2) {
			this.sinir_2 = sinir_2;
		}
		public int getYuzde_3() {
			return yuzde_3;
		}
		public void setYuzde_3(int yuzde_3) {
			this.yuzde_3 = yuzde_3;
		}
		public double getSinir_3() {
			return sinir_3;
		}
		public void setSinir_3(double sinir_3) {
			this.sinir_3 = sinir_3;
		}
		public int getYuzde_4() {
			return yuzde_4;
		}
		public void setYuzde_4(int yuzde_4) {
			this.yuzde_4 = yuzde_4;
		}
		public double getSinir_4() {
			return sinir_4;
		}
		public void setSinir_4(double sinir_4) {
			this.sinir_4 = sinir_4;
		}
		public int getYuzde_5() {
			return yuzde_5;
		}
		public void setYuzde_5(int yuzde_5) {
			this.yuzde_5 = yuzde_5;
		}
		public double getSinir_5() {
			return sinir_5;
		}
		public void setSinir_5(double sinir_5) {
			this.sinir_5 = sinir_5;
		}
		public int getYuzde_6() {
			return yuzde_6;
		}
		public void setYuzde_6(int yuzde_6) {
			this.yuzde_6 = yuzde_6;
		}
		public double getSinir_6() {
			return sinir_6;
		}
		public void setSinir_6(double sinir_6) {
			this.sinir_6 = sinir_6;
		}
		public int getYuzde_7() {
			return yuzde_7;
		}
		public void setYuzde_7(int yuzde_7) {
			this.yuzde_7 = yuzde_7;
		}
		public double getSinir_7() {
			return sinir_7;
		}
		public void setSinir_7(double sinir_7) {
			this.sinir_7 = sinir_7;
		}
		public int getYuzde_8() {
			return yuzde_8;
		}
		public void setYuzde_8(int yuzde_8) {
			this.yuzde_8 = yuzde_8;
		}
		public double getSinir_8() {
			return sinir_8;
		}
		public void setSinir_8(double sinir_8) {
			this.sinir_8 = sinir_8;
		}
		public double getVekalet_ucret() {
			return vekalet_ucret;
		}
		public void setVekalet_ucret(double vekalet_ucret) {
			this.vekalet_ucret = vekalet_ucret;
		}
		public double getVekalet_ucret_sinir() {
			return vekalet_ucret_sinir;
		}
		public void setVekalet_ucret_sinir(double vekalet_ucret_sinir) {
			this.vekalet_ucret_sinir = vekalet_ucret_sinir;
		}

	 	
}
