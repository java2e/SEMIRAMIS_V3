package pelops.model;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="TNM_AVUKAT")
public class Avukat extends BaseEntity  {
	
	@Column(name="ADI")
	private String adi;
	
	@Column(name="SOYADI")
	private String soyadi;
	
	@Column(name="KURUM_AVUKATI_MI")
	private Boolean kurumAvukatiMi;
	
	@Column(name="AVUKAT_SERVIS_NO")
	private String avukatServisNo;
	
	@OneToMany(fetch=FetchType.LAZY,mappedBy="avukat")
	private List<Adres> adres;
	
	@OneToMany(fetch=FetchType.LAZY,mappedBy="avukat")
	private List<IcraDosyasi> icraDosyasi;
	
}
