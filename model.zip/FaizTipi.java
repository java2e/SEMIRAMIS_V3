package pelops.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="TNM_FAIZ_TIPI")
public class FaizTipi extends BaseEntity{
	
	@Column(name="ADI")
	private String adi;

}
