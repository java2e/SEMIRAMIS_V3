package pelops.model;

public class BaseEntity {

}
