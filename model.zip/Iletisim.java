package pelops.model;

public class Iletisim {

	private int iletisimId;
	private String telefonStatusu;
	private String telefonNo;
	private int borcluId;

	public int getIletisimId() {
		return iletisimId;
	}

	public void setIletisimId(int iletisimId) {
		this.iletisimId = iletisimId;
	}

	public String getTelefonStatusu() {
		return telefonStatusu;
	}

	public void setTelefonStatusu(String telefonStatusu) {
		this.telefonStatusu = telefonStatusu;
	}

	public String getTelefonNo() {
		return telefonNo;
	}

	public void setTelefonNo(String telefonNo) {
		this.telefonNo = telefonNo;
	}

	public int getBorcluId() {
		return borcluId;
	}

	public void setBorcluId(int borcluId) {
		this.borcluId = borcluId;
	}
 
	

}
