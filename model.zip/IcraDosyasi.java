package pelops.model;


import java.sql.Time;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import semiramis.operasyon.model.DosyaStatusu;

@Entity
@Table(name="TNM_ICRA_DOSYASI")
public class IcraDosyasi extends BaseEntity {
	
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="ALACAKLI_BILGISI_ID")
	private AlacakliBilgisi alacakliBilgisi;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="AVUKAT_ID")
	private Avukat avukat;
	
	@Column(name="UYAP_DOSYA_TIPI")
	private String uyapDosyaTipi;
	@Column(name="KKDF")
	private String  KKDF;
	
	@Column(name="BSMV")
	private String BSMV;
	
	@Column(name="BK84")
	private String  BK84;
	
	@Column(name="UYAP_ROL_TURU")
	private String  uyapRolTuru;
	
	@Column(name="UYAP_ROL_ID")
	private String  uyapRolId;
	
	@Column(name="DIGER_ALACAK_ACIKLAMA")
	private String  digerAlacakAciklama;
	
	@Column(name="PARA_BIRIMI")
	private String  paraBirimi;
	
	@Column(name="UYAP_PARA_TURU")
	private String  uyapParaTuru;
	
	@Column(name="EKLEME_TARIHI")
	private Date   eklemeTarihi;
	
	@Column(name="GUNCELLEME_TARIHI")
	private Date  guncellemeTarihi ;
	
	@Column(name="BANKA_SERVIS_NO")
	private String bankaServisNo;
	
	@Column(name="SEMIRAMIS_NO")
	private String semiramisNo;
	
	@Column(name="ICRA_DOSYA_NO")
	private String icraDosyaNo;
	
	@Column(name="VADE_TARIHI")
	private Date vadeTarihi;
	
	@Column(name="IHTARNAME_TARIGI")
	private Date ihtarnameTarihi;
	
	@Column(name="GELIS_TARIHI")
	private Date gelisTarihi;
	
	@Column(name="TAKIP_TARIHI")
	private Date takipTarihi;
	
	@Column(name="TEBLIG_TARIHI")
	private Date tebligTarihi;
	
	@Column(name="BILA_TARIHI")
	private Date bilaTarihi;
	
	@Column(name="KESINLESME_TARIHI")
	private Date kesinlesmeTarihi;
	
	@Column(name="HITAM_TARIHI")
	private Date hitamTarihi;
	
	@Column(name="ICRA_KAPANIS_TARIHI")
	private Date icraKapanisTarihi;
	
	@Column(name="BANKA_KAPANIS_TARIHI")
	private Date bankaKapanisTarihi;
	
	@Column(name="GIDIS_TARIGI")
	private Date gidisTarihi;
	
	@Column(name="ITIRAZ_DURUMU")
	private String itirazDurumu;
	
	@Column(name="ITIRAZ_TARIHI")
	private Date itirazTarihi;
	
	@Column(name="HESAP_TIPI")
	private String hesapTipi;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="ITIRAZ_TIPI_ID")
	private ItirazTipi itirazTipi;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="ICRA_MUDURLUGU_ID")
	public IcraMudurlugu icraMudurlugu;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="DOSYA_STATUSU_ID")
	public DosyaStatusu dosyaStatusuId;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="DOSYA_TIPI_ID")
	public DosyaTipi dosyaTipi;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="TAKIP_TIPI_ID")
	public TakipTipi takipTipi;
	
	@Column(name="TAKIP_YOLU_ID")
	public int takipYoluId;
	
	@Column(name="TAKIP_SEKLI_ID")
	public int takipSekliId;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="BORCLU_TIPI")
	public BorcluTipi borcTipi;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="RISK_YONETICISI_ID")
	public User riskYoneticisiId;
	
	@Column(name="BORCA_ESAS_EVRAK")
	public String borcaEsasEvrak;
	
	@Column(name="TALEP_EDILEN_HAK")
	public String talepEdilenHak;
	
	@Column(name="VEKALET_UCRET_TIPI")
	public String vekaletUcretTipi;
	



}
