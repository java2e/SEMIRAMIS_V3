package pelops.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="TNM_ICRA_MUDURLUGU")
public class IcraMudurlugu extends BaseEntity {
	
	@Column(name="ADI")
	private String adi;
	
	@ManyToOne(fetch=FetchType.LAZY)
	private Il il;
	
	@ManyToOne(fetch=FetchType.LAZY)
	private Ilce ilce;

}
