package pelops.model;

public class MulkTipi {
	
	private int id;
	private int adi;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getAdi() {
		return adi;
	}
	public void setAdi(int adi) {
		this.adi = adi;
	}
	
	

}
