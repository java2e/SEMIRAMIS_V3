package pelops.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="TNM_DUYURU")
public class Duyuru extends BaseEntity {

	@Column(name="ACIKLAMA")
	private String aciklama;
	
	@Column(name="GUN_TARIH")
	private Date gunTarih;
	

}
