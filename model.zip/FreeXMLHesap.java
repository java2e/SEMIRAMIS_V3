package pelops.model;

public class FreeXMLHesap {

	private String asil_alacak;
	private String gecikme_faizi;
	private String faizin_gider_vergisi;
	private String noter_masrafi;
	private String takip_alacagi;
	private String temerrut_faiz_orani;
	
	
	private String alacakKalemTutar;
	private String alacakKalemKod;
	
	
	
	public String getAlacakKalemTutar() {
		return alacakKalemTutar;
	}
	public void setAlacakKalemTutar(String alacakKalemTutar) {
		this.alacakKalemTutar = alacakKalemTutar;
	}
	public String getAlacakKalemKod() {
		return alacakKalemKod;
	}
	public void setAlacakKalemKod(String alacakKalemKod) {
		this.alacakKalemKod = alacakKalemKod;
	}
	public String getAsil_alacak() {
		return asil_alacak;
	}
	public void setAsil_alacak(String asil_alacak) {
		this.asil_alacak = asil_alacak;
	}
	public String getGecikme_faizi() {
		return gecikme_faizi;
	}
	public void setGecikme_faizi(String gecikme_faizi) {
		this.gecikme_faizi = gecikme_faizi;
	}
	public String getFaizin_gider_vergisi() {
		return faizin_gider_vergisi;
	}
	public void setFaizin_gider_vergisi(String faizin_gider_vergisi) {
		this.faizin_gider_vergisi = faizin_gider_vergisi;
	}
	public String getNoter_masrafi() {
		return noter_masrafi;
	}
	public void setNoter_masrafi(String noter_masrafi) {
		this.noter_masrafi = noter_masrafi;
	}
	public String getTakip_alacagi() {
		return takip_alacagi;
	}
	public void setTakip_alacagi(String takip_alacagi) {
		this.takip_alacagi = takip_alacagi;
	}
	public String getTemerrut_faiz_orani() {
		return temerrut_faiz_orani;
	}
	public void setTemerrut_faiz_orani(String temerrut_faiz_orani) {
		this.temerrut_faiz_orani = temerrut_faiz_orani;
	}
	
	
	
}
