package pelops.model;

public class MuvekkilTipi {
	private int id;
	private String uyapKodu;
	private String adi;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getUyapKodu() {
		return uyapKodu;
	}
	public void setUyapKodu(String uyapKodu) {
		this.uyapKodu = uyapKodu;
	}
	public String getAdi() {
		return adi;
	}
	public void setAdi(String adi) {
		this.adi = adi;
	}
	
	
	
}
