package pelops.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="TNM_BORCLU_TIPI")
public class BorcluTipi {

	@Column(name="ADI")
	private String adi;

}
