package pelops.model;

public class MuameleAutoFields {

	private int icraMudurluguId;
	private String icraDosyaNo;
	private String muvekkilAdi;
	private int riskYoneticisiId;
	private String borcluAdresi;
	private String borcluAdi;
	private int dosyaStatusuId;
	private String semiramisNo;
	private String alacakliMail;
	private String buroAdresi;
	private String alacakliTel;
	private String icraMudurluguText;
	private String riskYoneticisiText;
	private String alacakliEpostaText;
	private String icraDosyaNoText;
	private String borcluAdresiText;
	private String buroAdresiText;
	private String alacakliTelText;
	private String borcluTcText;
	private String muvekkilAdiText;
	private Double borcMiktari;
	private String borcluDogumTarihi;
	
	public int getIcraMudurluguId() {
		return icraMudurluguId;
	}
	public void setIcraMudurluguId(int icraMudurluguId) {
		this.icraMudurluguId = icraMudurluguId;
	}
	public String getIcraDosyaNo() {
		return icraDosyaNo;
	}
	public void setIcraDosyaNo(String icraDosyaNo) {
		this.icraDosyaNo = icraDosyaNo;
	}
	public String getMuvekkilAdi() {
		return muvekkilAdi;
	}
	public void setMuvekkilAdi(String muvekkilAdi) {
		this.muvekkilAdi = muvekkilAdi;
	}
	public int getRiskYoneticisiId() {
		return riskYoneticisiId;
	}
	public void setRiskYoneticisiId(int riskYoneticisiId) {
		this.riskYoneticisiId = riskYoneticisiId;
	}
	public String getBorcluAdresi() {
		return borcluAdresi;
	}
	public void setBorcluAdresi(String borcluAdresi) {
		this.borcluAdresi = borcluAdresi;
	}
	public String getBorcluAdi() {
		return borcluAdi;
	}
	public void setBorcluAdi(String borcluAdi) {
		this.borcluAdi = borcluAdi;
	}
	public int getDosyaStatusuId() {
		return dosyaStatusuId;
	}
	public void setDosyaStatusuId(int dosyaStatusuId) {
		this.dosyaStatusuId = dosyaStatusuId;
	}
	public String getSemiramisNo() {
		return semiramisNo;
	}
	public void setSemiramisNo(String semiramisNo) {
		this.semiramisNo = semiramisNo;
	}
	public String getAlacakliMail() {
		return alacakliMail;
	}
	public void setAlacakliMail(String alacakliMail) {
		this.alacakliMail = alacakliMail;
	}
	public String getBuroAdresi() {
		return buroAdresi;
	}
	public void setBuroAdresi(String buroAdresi) {
		this.buroAdresi = buroAdresi;
	}
	public String getAlacakliTel() {
		return alacakliTel;
	}
	public void setAlacakliTel(String alacakliTel) {
		this.alacakliTel = alacakliTel;
	}
	public String getIcraMudurluguText() {
		return icraMudurluguText;
	}
	public void setIcraMudurluguText(String icraMudurluguText) {
		this.icraMudurluguText = icraMudurluguText;
	}
	public String getRiskYoneticisiText() {
		return riskYoneticisiText;
	}
	public void setRiskYoneticisiText(String riskYoneticisiText) {
		this.riskYoneticisiText = riskYoneticisiText;
	}
	public String getAlacakliEpostaText() {
		return alacakliEpostaText;
	}
	public void setAlacakliEpostaText(String alacakliEpostaText) {
		this.alacakliEpostaText = alacakliEpostaText;
	}
	public String getIcraDosyaNoText() {
		return icraDosyaNoText;
	}
	public void setIcraDosyaNoText(String icraDosyaNoText) {
		this.icraDosyaNoText = icraDosyaNoText;
	}
	public String getBorcluAdresiText() {
		return borcluAdresiText;
	}
	public void setBorcluAdresiText(String borcluAdresiText) {
		this.borcluAdresiText = borcluAdresiText;
	}
	public String getBuroAdresiText() {
		return buroAdresiText;
	}
	public void setBuroAdresiText(String buroAdresiText) {
		this.buroAdresiText = buroAdresiText;
	}
	public String getAlacakliTelText() {
		return alacakliTelText;
	}
	public void setAlacakliTelText(String alacakliTelText) {
		this.alacakliTelText = alacakliTelText;
	}
	public String getBorcluTcText() {
		return borcluTcText;
	}
	public void setBorcluTcText(String borcluTcText) {
		this.borcluTcText = borcluTcText;
	}
	public String getMuvekkilAdiText() {
		return muvekkilAdiText;
	}
	public void setMuvekkilAdiText(String muvekkilAdiText) {
		this.muvekkilAdiText = muvekkilAdiText;
	}
	public Double getBorcMiktari() {
		return borcMiktari;
	}
	public void setBorcMiktari(Double borcMiktari) {
		this.borcMiktari = borcMiktari;
	}
	public String getBorcluDogumTarihi() {
		return borcluDogumTarihi;
	}
	public void setBorcluDogumTarihi(String borcluDogumTarihi) {
		this.borcluDogumTarihi = borcluDogumTarihi;
	}

	
	
	
	
}
