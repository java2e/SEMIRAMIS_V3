package pelops.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="TNM_BASVURU_HARCI")
public class BasvuruHarci extends BaseEntity{

	@Column(name="YIL")
	private Integer yil;
	
	@Column(name="TUTAR")
	private Double tutar;
	
	@Column(name="KONUSU")
	private String konusu;
	
}
