package pelops.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="TNM_ADRES_TURU")
public class AdresTuru extends BaseEntity {

	@Column(name="ADI")
	String adi;
	
	@Column(name="UYAP_KODU")
	String uyapKodu;
	
}
