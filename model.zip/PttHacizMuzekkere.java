package pelops.model;

import java.sql.Date;

public class PttHacizMuzekkere {
	
	private String icraMudurluguAdi;
	private String icraDosyaNo;
	private Date tebligatTarihi;
	private String postaneAdi;
	private String il;
	private String ilce;
	private String vekili;
	private String adres;
	private String tel;
	private String email;
	private String borcluAdi;
	private int borcMiktari;
	private String alacakliAdi;
	
	
	
	
	
	public String getAlacakliAdi() {
		return alacakliAdi;
	}
	public void setAlacakliAdi(String alacakliAdi) {
		this.alacakliAdi = alacakliAdi;
	}
	public String getIcraMudurluguAdi() {
		return icraMudurluguAdi;
	}
	public void setIcraMudurluguAdi(String icraMudurluguAdi) {
		this.icraMudurluguAdi = icraMudurluguAdi;
	}
	public String getIcraDosyaNo() {
		return icraDosyaNo;
	}
	public void setIcraDosyaNo(String icraDosyaNo) {
		this.icraDosyaNo = icraDosyaNo;
	}
	public Date getTebligatTarihi() {
		return tebligatTarihi;
	}
	public void setTebligatTarihi(Date tebligatTarihi) {
		this.tebligatTarihi = tebligatTarihi;
	}
	public String getPostaneAdi() {
		return postaneAdi;
	}
	public void setPostaneAdi(String postaneAdi) {
		this.postaneAdi = postaneAdi;
	}
	public String getIl() {
		return il;
	}
	public void setIl(String il) {
		this.il = il;
	}
	public String getIlce() {
		return ilce;
	}
	public void setIlce(String ilce) {
		this.ilce = ilce;
	}
	public String getVekili() {
		return vekili;
	}
	public void setVekili(String vekili) {
		this.vekili = vekili;
	}
	public String getAdres() {
		return adres;
	}
	public void setAdres(String adres) {
		this.adres = adres;
	}
	public String getTel() {
		return tel;
	}
	public void setTel(String tel) {
		this.tel = tel;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getBorcluAdi() {
		return borcluAdi;
	}
	public void setBorcluAdi(String borcluAdi) {
		this.borcluAdi = borcluAdi;
	}
	public int getBorcMiktari() {
		return borcMiktari;
	}
	public void setBorcMiktari(int borcMiktari) {
		this.borcMiktari = borcMiktari;
	}
	
	
	
	
	
	
	

}
